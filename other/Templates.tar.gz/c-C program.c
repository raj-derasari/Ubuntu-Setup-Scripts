#include<stdio.h>
#include<math.h> // if you're into that

#define VAR1 A

int main(int* argc, char** argv){
printf("Hi World");

return 0;
}
