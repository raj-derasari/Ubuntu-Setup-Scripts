// not sure this works
#include<bits/stc++.h>
using namespace std;
int main(int* argc, char** argv){
cout<<"Hi World";

return 0;
}
