#!/bin/bash 
echo "This is the setup script for helping you configure NVIDIA for running Tensorflow on Cuda!"
echo "please note, you must input the Cuda Capability Version of your GPU, which you can find on nvidia.com!"

echo "This script is not unattended! To run it unattended, please run it as \"bash nvidia_setup_cuda.sh y\""
sudo apt-key adv --fetch-keys http://developer.download.nvidia.com/compute/cuda/repos/ubuntu1604/x86_64/7fa2af80.pub
wget http://developer.download.nvidia.com/compute/cuda/repos/ubuntu1604/x86_64/cuda-repo-ubuntu1604_9.1.85-1_amd64.deb
sudo dpkg -i cuda-repo-ubuntu1604_9.1.85-1_amd64.deb
sudo apt-get update;
sudo apt-get install -y build-essential cmake git python2.7-dev python3.5-dev pylint libcupti-dev bazel curl

if test $1 = "y"; then
	echo "NVIDIA-CUDA: install nvidia drivers and cuda --- Automated mode" >> $LOGGER
	sudo apt-get install -y cuda
else
	echo "NVIDIA-CUDA: install nvidia drivers and cuda --- 2GB download size. Continue?" >> $LOGGER
	sudo apt-get install cuda
fi

#sudo shutdown -R

echo "export PATH=/usr/local/cuda-9.1/bin${PATH:+:${PATH}}" >> ~/.bashrc
echo "export LD_LIBRARY_PATH=/usr/local/cuda-9.1/lib64${LD_LIBRARY_PATH:+:${LD_LIBRARY_PATH}}" >> ~/.bashrc

echo "installing CuDNN 7.1 from Local Tar File!"
#curl http://developer.download.nvidia.com/compute/machine-learning/cudnn/secure/v7.1.1/prod/9.1_20180214/cudnn-9.1-linux-x64-v7.1.tgz
tar -zxvf cudnn-9.1-linux-x64-v7.1.tgz
sudo cp cuda/include/cudnn.h /usr/local/cuda/include
sudo cp cuda/lib64/libcudnn* /usr/local/cuda/lib64
sudo chmod a+r /usr/local/cuda/include/cudnn.h
sudo chmod a+r /usr/local/cuda/lib64/libcudnn*

echo "installing Tensorflow from script now!"