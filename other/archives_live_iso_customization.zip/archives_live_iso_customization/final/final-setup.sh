#!/bin/bash
rm -rf ~/SetupScript
mkdir -p ~/SetupScript
cd ~/SetupScript
git clone https://github.com/raj-derasari/My-Ubuntu-Setup-Scripts
cd My-Ubuntu-Setup-Scripts
echo "READY"
chmod 777 master.sh