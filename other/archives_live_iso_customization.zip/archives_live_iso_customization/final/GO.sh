#!/bin/bash
bash set0.sh /etc/skel/.bashrc
bash set0.sh /root/.bashrc
bash set1and2and3.sh 2>>errors.log
