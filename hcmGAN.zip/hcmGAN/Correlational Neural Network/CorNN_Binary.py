from __future__ import division
import tensorflow as tf
import os, random
import numpy as np
from tensorflow.contrib.layers import l2_regularizer, xavier_initializer
import matplotlib.pyplot as plt

l2_scale = 0.001
batchsize = 64
noEpochs = 500

# Correlation neural network model
def CorNN(leftX, rightY, reuse=False):
    with tf.variable_scope('CorNN', reuse=reuse, regularizer=l2_regularizer(l2_scale)):
        X, Y = leftX, rightY
        W = tf.get_variable('corNN_W1', shape=[left_dim, 128])  # dim = d1 * k
        V = tf.get_variable('corNN_V1', shape=[right_dim, 128]) # dim = d2 * k
        b = tf.get_variable('corNN_b1', shape=[128]) # dim = k
        h_x = tf.matmul(X, W) # dim = batchsize * k
        h_y = tf.matmul(Y, V) # dim = batchsize * k
        h_z = tf.nn.tanh(h_x + h_y + b)# dim = batchsize * k

        W_hat = tf.get_variable('corNN_W_hat1', shape=[128, left_dim])        # dim = k * d1
        V_hat = tf.get_variable('corNN_V_hat1', shape=[128, right_dim])        # dim = k * d2
        b_hat = tf.get_variable('corNN_b_hat1', shape=[left_dim + right_dim])        # dim = d1 + d2
        h_xhat = tf.matmul(h_z, W_hat)        # dim = batchsize * d1
        h_yhat = tf.matmul(h_z, V_hat)        # dim = batchsize * d2
        h_con = tf.concat([h_xhat, h_yhat], 1)        # dim = batchsize * (d1+d2)
        z_hat = tf.nn.sigmoid(tf.add(h_con, b_hat))        # dim = batchsize * (d1+d2)
        return z_hat, h_x, h_y

# load skill-matrix
mat1 = np.load('matrix.npy')
# load profession matrix
mat2 = np.load('class_mat.npy')

# shuffle both the matrix with same indexes
shuffle_index = np.arange(mat1.shape[0])
np.random.shuffle(shuffle_index)
left_mat = mat1[shuffle_index]
right_mat = mat2[shuffle_index]

# take training and testing data-set
dim = int(left_mat.shape[0]*0.8)
left_mat_train = left_mat[:dim]
right_mat_train = right_mat[:dim]
left_mat_test = left_mat[dim:]
right_mat_test = right_mat[dim:]

# take dimensions for x-view and y-view
left_dim = left_mat_train.shape[1]
right_dim = right_mat_train.shape[1]

# create placeholder
left_input = tf.placeholder('float', [None, left_dim])
right_input = tf.placeholder('float', [None, right_dim])
left_zeros = tf.placeholder('float', [None, left_dim])
right_zeros = tf.placeholder('float', [None, right_dim])

# functions
recon_z, h_X, h_Y = CorNN(left_input, right_input)
cross_x, _, _ = CorNN(left_input, right_zeros, reuse=True)
cross_y, _, _ = CorNN(left_zeros, right_input, reuse=True)

# loss functions
input_data = tf.concat([left_input, right_input],1)
recon_loss = tf.reduce_mean(-tf.reduce_sum(input_data * tf.log(recon_z + 1e-12) + (1. - input_data) * tf.log(1. - recon_z + 1e-12), 1), 0)
crossx_loss = tf.reduce_mean(-tf.reduce_sum(input_data * tf.log(cross_x + 1e-12) + (1. - input_data) * tf.log(1. - cross_x + 1e-12), 1), 0)
crossy_loss = tf.reduce_mean(-tf.reduce_sum(input_data * tf.log(cross_y + 1e-12) + (1. - input_data) * tf.log(1. - cross_y + 1e-12), 1), 0)

# find correlation between latent spaces
hx = h_X - tf.reduce_mean(h_X, axis=0)
hy = h_Y - tf.reduce_mean(h_Y, axis=0)
normalize_hx = tf.reduce_sum(hx**2)
normalize_hy = tf.reduce_sum(hy**2)
latent_loss = tf.reduce_sum(tf.matmul(hx, tf.transpose(hy)))/(tf.sqrt(normalize_hx*normalize_hy))

# final loss functions
total_loss = recon_loss + crossx_loss + crossy_loss - latent_loss

# pool out trainable variables for optimization
t_vars = tf.trainable_variables()
cornn_vars = [var for var in t_vars if 'CorNN' in var.name]
all_regs = tf.get_collection(tf.GraphKeys.REGULARIZATION_LOSSES)
optimize = tf.train.AdamOptimizer().minimize(total_loss+sum(all_regs), var_list=cornn_vars)

initOp = tf.global_variables_initializer()

if not os.path.exists('result'):
    os.makedirs('result')

noBatches = int(left_mat_train.shape[0]/batchsize)
idx = np.arange(left_mat_train.shape[0])
with tf.Session() as sess:
    sess.run(initOp)
    for epoch in range(noEpochs):
        cor_loss = []
        for _ in range(noBatches):
            batchIdx = np.random.choice(idx, size=batchsize, replace=False)
            l_input, r_input = left_mat_train[batchIdx], right_mat_train[batchIdx]
            l_zeros = np.zeros([batchsize, left_dim])
            r_zeros = np.zeros([batchsize, right_dim])
            _, loss = sess.run([optimize, total_loss], feed_dict={left_input:l_input, right_input:r_input, left_zeros: l_zeros, right_zeros: r_zeros})
            cor_loss.append(loss)
        print 'Epoch:- ',epoch,', Correlation Loss:- ', np.mean(cor_loss)

        if epoch%10==0:
            # test_set = left_mat_test.shape[0]
            # r_input = np.zeros([test_set, right_dim])
            # generated = sess.run(recon_z, feed_dict={left_input:left_mat_test, right_input:r_input})
            # generated = generated[:,left_dim:]
            # original = right_mat_test
            #
            # counter = 0
            # for i in range(test_set):
            #     max_index1 = list(generated[i]).index(max(list(generated[i])))
            #     max_index2 = list(original[i]).index(max(list(original[i])))
            #     if max_index1==max_index2 and generated[i][max_index1]>0.7:
            #         counter+=1
            # print counter/test_set
            jobtitle = ['application developer','web designer','net developer','java developer','application support analyst','applications engineer']

            test_set = right_mat_test.shape[0]
            l_input = np.zeros([test_set, left_dim])
            generated = sess.run(recon_z, feed_dict={left_input:l_input, right_input:right_mat_test})
            generated = generated[:,:left_dim]
            original = left_mat_test

            counter = 0
            skills = np.load('skills.npy')
            file_d = open('result/correlation_xavier.txt','a+')
            for i in range(10):
                max_index = list(right_mat_test[i]).index(max(list(right_mat_test[i])))
                file_d.write('Epoch :- '+str(epoch)+'\n')
                file_d.write('jobtitle :- '+str(jobtitle[max_index])+'\n')
                org_str = ''
                for j in range(len(original[i])):
                    if original[i][j]==1:
                        org_str += str(skills[j])+', '
                file_d.write('original data :- '+org_str+'\n')
                gen_str = ''
                for j in range(len(generated[i])):
                    if generated[i][j]>0.5:
                        gen_str += str(skills[j])+', '
                file_d.write('generate data :- '+gen_str+'\n\n')
            file_d.close()
