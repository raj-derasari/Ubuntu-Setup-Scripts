def corAutoEncoder(x_raw, y_raw, reuse=False):
    with tf.variable_scope('corAutoEncoder', reuse=reuse, regularizer=l2_regularizer(l2_scale)):

        if epoch<500:
            h_x, h_y, ldim, rdim = x_raw, y_raw, left_dim, right_dim
            i = 0
            for encodedim in encoderdim[:-1]:
                W = tf.get_variable('corEnc_W'+str(i), shape=[ldim, encodedim])
                V = tf.get_variable('corEnc_V'+str(i), shape=[rdim, encodedim])
                b = tf.get_variable('corEnc_b'+str(i), shape=[encodedim])
                h_x = tf.nn.sigmoid(tf.matmul(h_x, W) + b)
                h_y = tf.nn.sigmoid(tf.matmul(h_y, V) + b)
                ldim = encodedim
                rdim = encodedim
                i+=1
            W = tf.get_variable('corEnc_W'+str(i), shape=[ldim, encoderdim[-1]])
            V = tf.get_variable('corEnc_V'+str(i), shape=[rdim, encoderdim[-1]])
            b = tf.get_variable('corEnc_b'+str(i), shape=[encoderdim[-1]])
            h_x = tf.matmul(h_x, W)
            h_y = tf.matmul(h_y, V)
            h_z = tf.nn.sigmoid(h_x + h_y + b)

            h_xhat, h_yhat, ldim, rdim = h_z, h_z, squeezeDim, squeezeDim
            i = 0
            for decodedim in decoderdim:
                W_hat = tf.get_variable('corDec_W'+str(i), shape=[ldim, decodedim])
                V_hat = tf.get_variable('corDec_V'+str(i), shape=[rdim, decodedim])
                b_hat = tf.get_variable('corDec_b'+str(i), shape=[decodedim])
                h_xhat = tf.nn.sigmoid(tf.matmul(h_xhat, W_hat) + b_hat)
                h_yhat = tf.nn.sigmoid(tf.matmul(h_yhat, V_hat) + b_hat)
                ldim = decodedim
                rdim = decodedim
                i+=1
            W_hat = tf.get_variable('corDec_W'+str(i), shape=[ldim, left_dim])
            V_hat = tf.get_variable('corDec_V'+str(i), shape=[rdim, right_dim])
            b_hat = tf.get_variable('corDec_b'+str(i), shape=[left_dim + right_dim])
            h_xhat = tf.matmul(h_xhat, W_hat)
            h_yhat = tf.matmul(h_yhat, V_hat)
            h_con = tf.concat([h_xhat, h_yhat], 1)
            z_hat = tf.nn.sigmoid(tf.add(h_con, b_hat))

        else:
            h_x, h_y, ldim, rdim = x_raw, y_raw, left_dim, right_dim
            i = 0
            for encodedim in encoderdim[:-1]:
                W = tf.get_variable('corEnc_W'+str(i), shape=[ldim, encodedim])
                V = tf.get_variable('corEnc_V'+str(i), shape=[rdim, encodedim])
                b = tf.get_variable('corEnc_b'+str(i), shape=[encodedim])
                h_x = tf.nn.sigmoid(tf.matmul(h_x, W) + b)
                h_y = tf.nn.sigmoid(tf.matmul(h_y, V) + b)
                ldim = encodedim
                rdim = encodedim
                i+=1
            W = tf.get_variable('corEnc_W'+str(i), shape=[ldim, encoderdim[-1]])
            V = tf.get_variable('corEnc_V'+str(i), shape=[rdim, encoderdim[-1]])
            b = tf.get_variable('corEnc_b'+str(i), shape=[encoderdim[-1]])
            h_x = tf.matmul(h_x, W)
            h_y = tf.matmul(h_y, V)
            h_z = tf.nn.sigmoid(h_x + h_y + b)

            h_xhat, h_yhat, ldim, rdim = h_z, h_z, squeezeDim, squeezeDim
            i = 0
            for decodedim in decoderdim:
                W_hat = tf.get_variable('corDec_W'+str(i), shape=[ldim, decodedim])
                V_hat = tf.get_variable('corDec_V'+str(i), shape=[rdim, decodedim])
                b_hat = tf.get_variable('corDec_b'+str(i), shape=[decodedim])
                h_xhat = tf.nn.sigmoid(tf.matmul(h_xhat, W_hat) + b_hat)
                h_yhat = tf.nn.sigmoid(tf.matmul(h_yhat, V_hat) + b_hat)
                ldim = decodedim
                rdim = decodedim
                i+=1
            W_hat = tf.get_variable('corDec_W'+str(i), shape=[ldim, left_dim])
            V_hat = tf.get_variable('corDec_V'+str(i), shape=[rdim, right_dim])
            b_hat = tf.get_variable('corDec_b'+str(i), shape=[left_dim + right_dim])
            h_xhat = tf.matmul(h_xhat, W_hat)
            h_yhat = tf.matmul(h_yhat, V_hat)
            h_con = tf.concat([h_xhat, h_yhat], 1)
            z_hat = tf.nn.sigmoid(tf.add(h_con, b_hat))


        return z_hat, h_xhat, h_yhat
