import tensorflow as tf
import os
import numpy as np
from tensorflow.contrib.layers import l2_regularizer
import matplotlib.pyplot as plt

from tensorflow.examples.tutorials.mnist import input_data
mnist = input_data.read_data_sets("MNIST_data/", one_hot=True)

l2_scale = 0.001
batchsize = 64
noEpochs = 1000

def spliter(mat, ratio):
    dim = mat.shape[1]
    left = int(dim*ratio)
    left_mat = mat[:, :left]
    right_mat = mat[:, left:]
    return left_mat, right_mat

def CorNN(leftX, rightY, reuse=False):
    with tf.variable_scope('CorNN', reuse=reuse, regularizer=l2_regularizer(l2_scale)):
        X, Y = leftX, rightY
        W = tf.get_variable('corNN_W1', shape=[left_dim, 128])  # dim = d1 * k
        V = tf.get_variable('corNN_V1', shape=[right_dim, 128]) # dim = d2 * k
        b = tf.get_variable('corNN_b1', shape=[128]) # dim = k
        h_x = tf.matmul(X, W) # dim = batchsize * k
        h_y = tf.matmul(Y, V) # dim = batchsize * k
        h_z = tf.nn.relu(h_x + h_y + b)# dim = batchsize * k

        W_hat = tf.get_variable('corNN_W_hat1', shape=[128, left_dim])        # dim = k * d1
        V_hat = tf.get_variable('corNN_V_hat1', shape=[128, right_dim])        # dim = k * d2
        b_hat = tf.get_variable('corNN_b_hat1', shape=[left_dim + right_dim])        # dim = d1 + d2
        h_xhat = tf.matmul(h_z, W_hat)        # dim = batchsize * d1
        h_yhat = tf.matmul(h_z, V_hat)        # dim = batchsize * d2
        h_con = tf.concat([h_xhat, h_yhat], 1)        # dim = batchsize * (d1+d2)
        z_hat = tf.nn.sigmoid(tf.add(h_con, b_hat))        # dim = batchsize * (d1+d2)
        return z_hat, h_x, h_y

# load mnist data
mnistX_train = mnist.train.images
mnistX_test = mnist.test.images

# split data into two parts - x-view and y-view
# feature vector of 784 = x-view of 392  + y-view of 392
left_mat, right_mat = spliter(mnistX_train, 0.5)
left_test_mat, right_test_mat = spliter(mnistX_test, 0.5)

# dimensions of views
left_dim = left_mat.shape[1]
right_dim = right_mat.shape[1]

# placeholders
left_input = tf.placeholder('float', [None, left_dim])
right_input = tf.placeholder('float', [None, right_dim])
left_zeros = tf.placeholder('float', [None, left_dim])
right_zeros = tf.placeholder('float', [None, right_dim])

# functions for reconstruction, cross reconstruction
recon_z, h_X, h_Y = CorNN(left_input, right_input)
cross_x, _, _ = CorNN(left_input, right_zeros, reuse=True)
cross_y, _, _ = CorNN(left_zeros, right_input, reuse=True)

# loss functions
input_data = tf.concat([left_input, right_input],1)
recon_loss = tf.reduce_sum((input_data - recon_z)**2)
crossx_loss = tf.reduce_sum((input_data - cross_x)**2)
crossy_loss = tf.reduce_sum((input_data - cross_y)**2)

# find correlation between latent spaces
hx_centered = h_X - tf.reduce_mean(h_X, axis=0)
hy_centered = h_Y - tf.reduce_mean(h_Y, axis=0)
corr_nr = tf.reduce_sum(hx_centered * hy_centered, axis=0)
corr_dr1 = tf.sqrt(tf.reduce_sum(hx_centered * hx_centered, axis=0))
corr_dr2 = tf.sqrt(tf.reduce_sum(hy_centered * hy_centered, axis=0))
corr_dr = corr_dr1 * corr_dr2
corr = corr_nr/corr_dr
latent_loss = tf.reduce_sum(corr)

# compute total loss
total_loss = recon_loss + crossx_loss + crossy_loss - latent_loss

# pool out trainable variables for optimization
t_vars = tf.trainable_variables()
cornn_vars = [var for var in t_vars if 'CorNN' in var.name]
all_regs = tf.get_collection(tf.GraphKeys.REGULARIZATION_LOSSES)
optimize = tf.train.AdamOptimizer().minimize(total_loss+sum(all_regs), var_list=cornn_vars)

initOp = tf.global_variables_initializer()

if not os.path.exists('result'):
    os.makedirs('result')

noBatches = int(left_mat.shape[0]/batchsize)
idx = np.arange(left_mat.shape[0])
with tf.Session() as sess:
    sess.run(initOp)
    for epoch in range(noEpochs):
        cor_loss = []
        for _ in range(noBatches):
            batchIdx = np.random.choice(idx, size=batchsize, replace=False)
            l_input, r_input = left_mat[batchIdx], right_mat[batchIdx]
            l_zeros = np.zeros([batchsize, left_dim])
            r_zeros = np.zeros([batchsize, right_dim])
            _, loss = sess.run([optimize, total_loss], feed_dict={left_input:l_input, right_input:r_input, left_zeros: l_zeros, right_zeros: r_zeros})
            cor_loss.append(loss)
        print 'Epoch:- ',epoch,', Correlation Loss:- ', np.mean(cor_loss)

        if epoch%10==0:
            l_input = left_test_mat[:2]
            r_input = np.zeros([2, right_dim])
            generated = sess.run(recon_z, feed_dict={left_input:l_input, right_input:r_input})

            plt.subplot(2, 2, 1)
            plt.imshow(np.reshape(mnist.test.images[0],(28,28)), cmap='gray')
            plt.title('Test image 1')
            plt.subplot(2, 2, 2)
            plt.imshow(np.reshape(generated[0],(28,28)),cmap='gray')
            plt.title('Autoencoded image 1')
            plt.subplot(2, 2, 3)
            plt.imshow(np.reshape(mnist.test.images[1],(28,28)), cmap='gray')
            plt.title('Test image 2')
            plt.subplot(2, 2, 4)
            plt.imshow(np.reshape(generated[1],(28,28)),cmap='gray')
            plt.title('Autoencoded image 2')
            plt.savefig('result/epoch_'+str(epoch)+'.png')
