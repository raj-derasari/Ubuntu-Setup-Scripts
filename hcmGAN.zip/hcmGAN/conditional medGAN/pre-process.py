import numpy as np

def write(data,filename):
	np.save(filename,data)

def read(filename):
	data = np.load(filename)
	return data

skl_train = read('matrix.npy')
#labels = read('labels.npy')
#mean = read('mean.npy')
class_mat = read('class_mat.npy')
#final = read('final2.npy')
skills = read('skills.npy')

#row,column = skl_train.shape[0],skl_train.shape[1]
#class_mat_2 = np.zeros([row,column])

#for i in range(row):
#	ind = mean[int(labels[i])].argsort()[-3:][::-1]
#	class_mat_2[i][ind] = 1
fre = np.zeros([1,6])

for i in range(len(class_mat)):
	ind = np.where(class_mat[i]==1)
	fre[0][ind] +=1


print fre 

no_job_pro = len(skl_train)
no_skills = len(skl_train[0])

print no_job_pro
print no_skills

mean = 0
maxi = 0
mini = 1000
count = []
for i in range(len(skl_train)):
	cou = np.count_nonzero(skl_train[i]==1)
	if cou>maxi:
		maxi=cou
	if cou<mini:
		mini=cou
	mean+=cou 
	count.append(cou)

mean = int(mean/no_job_pro)

print mean
print maxi
print mini

count = sorted(count)

if len(count)%2==0:
	print (count[int(len(count)/2)]+count[int(len(count)/2)+1])/2
else:
	print count[int((len(count)+1)/2)]
