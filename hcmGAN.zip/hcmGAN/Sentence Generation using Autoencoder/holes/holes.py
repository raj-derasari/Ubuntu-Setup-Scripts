import nltk
from nltk.corpus import state_union
from nltk.tokenize import PunktSentenceTokenizer #unsupervised ML sentence tokenizer

train_text=state_union.raw("2005-GWBush.txt")

f=open("sentences.txt","rb")
sample_text=f.read()

custom_sent_tokenizer= PunktSentenceTokenizer(train_text)
tokenized = custom_sent_tokenizer.tokenize(sample_text)


def process_content():
    #try:
    final=[]
    final2=[]
    for i in range(len(tokenized)):
        words=nltk.word_tokenize(tokenized[i])
        tagged=nltk.pos_tag(words)
        cnt=0
        for j in range(len(words)):
            if tagged[j][1]=="DT":
                words[j]="<unk>"
                cnt=cnt+1
            #print(tagged)
        if cnt==1:
            final2.append(tokenized[i])
            tokenized[i]=' '.join(words)
            final.append(tokenized[i])
            print tokenized[i]

    print len(final)

    f2=open("holes.txt","wb")
    f2.write('\n'.join(final))
    f3=open("original.txt","wb")
    f3.write('\n'.join(final2))
    #except Exception as e:
    #    print(str(e))


process_content()
