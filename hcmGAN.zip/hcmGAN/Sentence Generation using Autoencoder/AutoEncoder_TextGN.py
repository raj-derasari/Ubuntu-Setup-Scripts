import numpy as np #vectorization
import random, re #generate probability distribution
import tensorflow as tf #ml
from tensorflow.contrib.layers import l2_regularizer

# define string length in terms words
strings_per_sen = 15
# string_set
string_set = set()
# cleaning function
def cleanString(string):
    str_ = re.sub('[^ ,.A-Za-z0-9]+', '', string)
    str_ = str_.strip()
    str_ = ' '.join(str_.split())
    return str_

# real raw wikipedia data file
train_text = open('wikitext-2-raw/wiki.train.raw').read()
# valid_text = open('wikitext-2-raw/wiki.valid.raw').read()
# test_text = open('wikitext-2-raw/wiki.test.raw').read()
#
text = train_text

# print train_text[:3000]

# define new_text list to store equal length sentences
new_text = []
# split text from .
text = text.split('.')
summ = 0
count=0
for i in range(len(text)):
    cleaned = cleanString(text[i])
    dummy = cleaned.split()
    summ+=len(dummy)
    count+=1
    # if len(dummy)==strings_per_sen:
    #     new_text.append(cleaned)
    #     string_set.update(dummy)
print float(summ)/count
# string_set = sorted(string_set)
# string_size = len(string_set)
# sections = len(new_text)
#
# print 'Number of sentences :- ', sections
# print 'Number of string per sentences :- ', strings_per_sen
# print 'Number of unique strings :- ', string_size
#
# word2id = dict((w, i) for i, w in enumerate(string_set))
# id2word = dict((i, w) for i, w in enumerate(string_set))
#
# X = np.zeros((sections,strings_per_sen,string_size))
#
# for i, section in enumerate(new_text):
#     for j, string in enumerate(section.split()):
#         X[i,j,word2id[string]]=1
#
# # create corrupted matrix
# def corruptedMatrix(mat,remove):
#     temp = mat
#     for i in range(temp.shape[0]):
#         idx = np.arange(temp.shape[1])
#         randomidx = np.random.choice(idx, size=remove, replace=False)
#         temp[i][randomidx] = np.zeros([1,temp.shape[2]])
#     return temp
# # encoder
# def encoder(train_x, batch_size, inputdim, squeezedim):
#     with tf.variable_scope('encoder', regularizer=l2_regularizer(0.001)):
#         layer_1_dim = 256
#         layer_2_dim = 128
#         layer_3_dim = squeezedim
#
#         W_el1 = tf.Variable(tf.random_normal([batch_size, inputdim, layer_1_dim], stddev=0.1),name="W_el1")
#         b_el1 = tf.Variable(tf.zeros([layer_1_dim]), name="b_el1")
#         e_h1 = tf.nn.tanh(tf.add(tf.matmul(train_x,W_el1),b_el1))
#
#         W_el2 = tf.Variable(tf.random_normal([batch_size, layer_1_dim, layer_2_dim], stddev=0.1),name="W_el2")
#         b_el2 = tf.Variable(tf.zeros([layer_2_dim]), name="b_el2")
#         e_h2 = tf.nn.tanh(tf.add(tf.matmul(e_h1,W_el2),b_el2))
#
#         W_el3 = tf.Variable(tf.random_normal([batch_size, layer_2_dim, layer_3_dim], stddev=0.1),name="W_el3")
#         b_el3 = tf.Variable(tf.zeros([layer_3_dim]), name="b_el3")
#         e_h3 = tf.nn.tanh(tf.add(tf.matmul(e_h2,W_el3),b_el3))
#     return e_h3
#
# # decoder
# def decoder(encoded_x, batch_size, squeezedim, outputdim):
#     with tf.variable_scope('decoder',regularizer=l2_regularizer(0.001)):
#         layer_1_dim = 128
#         layer_2_dim = 256
#         layer_3_dim = outputdim
#
#         W_dl1 = tf.Variable(tf.random_normal([batch_size, squeezedim, layer_1_dim], stddev=0.1),name="W_dl1")
#         b_dl1 = tf.Variable(tf.zeros([layer_1_dim]), name="b_dl1")
#         d_h1 = tf.nn.tanh(tf.add(tf.matmul(encoded_x,W_dl1),b_dl1))
#
#         W_dl2 = tf.Variable(tf.random_normal([batch_size, layer_1_dim, layer_2_dim], stddev=0.1),name="W_dl2")
#         b_dl2 = tf.Variable(tf.zeros([layer_2_dim]), name="b_dl2")
#         d_h2 = tf.nn.tanh(tf.add(tf.matmul(d_h1,W_dl2),b_dl2))
#
#         W_dl3 = tf.Variable(tf.random_normal([batch_size, layer_2_dim, layer_3_dim], stddev=0.1),name="W_dl3")
#         b_dl3 = tf.Variable(tf.zeros([layer_3_dim]), name="b_dl3")
#         d_h3 = tf.nn.sigmoid(tf.add(tf.matmul(d_h2,W_dl3),b_dl3))
#     return d_h3
#
# rem = 1
# #########################################
# # Partition into train, valid and test set
# var = int(sections*0.8)
# X_copy = np.copy(X)
# corrupted = corruptedMatrix(X,rem)
#
# train_x = X_copy[:var]
# test_x = X_copy[var:]
# c_train_x = corrupted[:var]
# c_test_x = corrupted[var:]
#
# #########################################
# # Hyperparameter
# batchSize = 16
# squeezedim = 64
# training_Epoch = 100000
#
# # placeholders for input of encoder and decoder
# encoder_input = tf.placeholder(tf.float32,shape=[None, strings_per_sen, string_size])
# x_real = tf.placeholder(tf.float32, shape=[None, strings_per_sen, string_size])
#
# encoder_output = encoder(encoder_input,batchSize, string_size, squeezedim)
# decoder_output = decoder(encoder_output,batchSize, squeezedim, string_size)
#
# ae_loss = tf.reduce_mean(tf.pow(decoder_output-x_real,2))
# train_en = tf.train.AdamOptimizer().minimize(ae_loss)
# idx = np.arange(train_x.shape[0])
# saver = tf.train.Saver()
#
# with tf.Session() as sess:
#     # sess.run(tf.global_variables_initializer())
#     # #First let's load meta graph and restore weights
#     saver = tf.train.import_meta_graph('model/my_test_model-20100.meta')
#     saver.restore(sess,tf.train.latest_checkpoint('model/'))
#
#     r_x = test_x[:batchSize]
#     c_x = c_test_x[:batchSize]
#     decoded = sess.run([decoder_output],feed_dict={encoder_input:c_x})
#
#     print '\n\n\n'
#     for check in range(batchSize):
#         strr=''
#         for i in range(r_x.shape[1]):
#             idx = np.where(r_x[check][i]==1)[0][0]
#             strr = strr + id2word[idx] + ' '
#         print 'original :- ', strr
#
#         strr=''
#         predicted=''
#         for i in range(c_x.shape[1]):
#             idx = np.where(c_x[check][i]==1)[0]
#             if not idx:
#                 try:
#                     if idx[0]==0:
#                         strr = strr + id2word[idx[0]] + ' '
#                 except:
#                     strr = strr + '____' + ' '
#                     idx = np.where(decoded[0][check][i]==max(decoded[0][check][i]))[0][0]
#                     predicted = id2word[idx]
#             else:
#                 strr = strr + id2word[idx[0]] + ' '
#         print 'corrupted :- ', strr
#
#         # strr=''
#         # for i in range(decoded[0].shape[1]):
#         #     idx = np.where(decoded[0][check][i]==max(decoded[0][check][i]))[0][0]
#         #     strr = strr + id2word[idx] + ' '
#         print 'predicted word :- ',  predicted,'\n\n\n'
#
#     # total_batch = int(train_x.shape[0]/batchSize)
#     # for epoch in range(training_Epoch):
#     #     train_loss = []
#     #     for i in range(total_batch):
#     #         batchIdx = np.random.choice(idx, size=batchSize, replace=False)
#     #         r_x = train_x[batchIdx]
#     #         c_x = c_train_x[batchIdx]
#     #         _, c = sess.run([train_en, ae_loss], feed_dict={x_real:r_x, encoder_input:c_x})
#     #         train_loss.append(c)
#     #     print 'Epoch :- ',(epoch+1),' AutoEncoder Loss', np.mean(train_loss)
#     #
#     #     if epoch%10==0:
#     #         with open('output.txt','a') as f:
#     #             print 'Printing'
#     #             f.write('Epoch :- '+str(epoch)+'------------->\n')
#     #             r_x = test_x[:batchSize]
#     #             c_x = c_test_x[:batchSize]
#     #             decoded = sess.run([decoder_output],feed_dict={encoder_input:c_x})
#     #
#     #             count=0
#     #             for i in range(decoded[0].shape[1]):
#     #                 print max(decoded[0][0][i])
#     #             f.write(str(count))
#     #         print 'Done'
#     #         saver.save(sess, 'model/my_test_model',global_step=epoch)
