import numpy as np #vectorization
import random, re #generate probability distribution
import tensorflow as tf #ml
from tensorflow.contrib.layers import l2_regularizer

################ Data for training and testing
f1 = open('original.txt','r')
f2 = open('holes.txt','r')

original = [line.rstrip('\n').lower() for line in f1.readlines()]
holes = [line.rstrip('\n').lower() for line in f2.readlines()]

tokens = set()
sections = 0
sentences_len = 5

for sentences in original:
    words = sentences.split()
    tokens.update(words)
    sections +=1

for sentences in holes:
    words = sentences.split()
    tokens.update(words)

no_tokens = len(tokens)

word2id = dict((w, i) for i, w in enumerate(tokens))
id2word = dict((i, w) for i, w in enumerate(tokens))

print 'No of tokens :- ', no_tokens
print 'No of sentences :- ', sections
print 'Sentence length :- ', sentences_len
print 'No of tokens/no of sentences :- ', float(no_tokens)/sections

org_mat = np.zeros((sections,sentences_len,no_tokens))

for i, sentences in enumerate(original):
    for j, words in enumerate(sentences.split()):
        org_mat[i,j,word2id[words]]=1

hol_mat = np.zeros((sections,sentences_len,no_tokens))

for i, sentences in enumerate(holes):
    for j, words in enumerate(sentences.split()):
        if words!='<unk>':
            hol_mat[i,j,word2id[words]]=1

shuffle = np.arange(org_mat.shape[0])
np.random.shuffle(shuffle)
org_mat = org_mat[shuffle]
hol_mat = hol_mat[shuffle]

# encoder
def encoder(train_x, batch_size, inputdim, squeezedim):
    with tf.variable_scope('encoder', regularizer=l2_regularizer(0.001)):
        layer_1_dim = 64
        layer_2_dim = 32
        layer_3_dim = squeezedim

        W_el1 = tf.Variable(tf.random_normal([batch_size, inputdim, layer_1_dim], stddev=0.1),name="W_el1")
        b_el1 = tf.Variable(tf.zeros([layer_1_dim]), name="b_el1")
        e_h1 = tf.nn.tanh(tf.add(tf.matmul(train_x,W_el1),b_el1))

        W_el2 = tf.Variable(tf.random_normal([batch_size, layer_1_dim, layer_2_dim], stddev=0.1),name="W_el2")
        b_el2 = tf.Variable(tf.zeros([layer_2_dim]), name="b_el2")
        e_h2 = tf.nn.tanh(tf.add(tf.matmul(e_h1,W_el2),b_el2))

        W_el3 = tf.Variable(tf.random_normal([batch_size, layer_2_dim, layer_3_dim], stddev=0.1),name="W_el3")
        b_el3 = tf.Variable(tf.zeros([layer_3_dim]), name="b_el3")
        e_h3 = tf.nn.tanh(tf.add(tf.matmul(e_h2,W_el3),b_el3))
    return e_h3

# decoder
def decoder(encoded_x, batch_size, squeezedim, outputdim):
    with tf.variable_scope('decoder',regularizer=l2_regularizer(0.001)):
        layer_1_dim = 32
        layer_2_dim = 64
        layer_3_dim = outputdim

        W_dl1 = tf.Variable(tf.random_normal([batch_size, squeezedim, layer_1_dim], stddev=0.1),name="W_dl1")
        b_dl1 = tf.Variable(tf.zeros([layer_1_dim]), name="b_dl1")
        d_h1 = tf.nn.tanh(tf.add(tf.matmul(encoded_x,W_dl1),b_dl1))

        W_dl2 = tf.Variable(tf.random_normal([batch_size, layer_1_dim, layer_2_dim], stddev=0.1),name="W_dl2")
        b_dl2 = tf.Variable(tf.zeros([layer_2_dim]), name="b_dl2")
        d_h2 = tf.nn.tanh(tf.add(tf.matmul(d_h1,W_dl2),b_dl2))

        W_dl3 = tf.Variable(tf.random_normal([batch_size, layer_2_dim, layer_3_dim], stddev=0.1),name="W_dl3")
        b_dl3 = tf.Variable(tf.zeros([layer_3_dim]), name="b_dl3")
        d_h3 = tf.nn.sigmoid(tf.add(tf.matmul(d_h2,W_dl3),b_dl3))
    return d_h3

#########################################
# Partition into train, valid and test set
var = int(sections*0.8)
train_x = org_mat[:var]
test_x = org_mat[var:]
c_train_x = hol_mat[:var]
c_test_x = hol_mat[var:]

print 'No of training sentences :- ', len(train_x)
print 'No of testing sentences :- ', len(test_x)

#########################################
# Hyperparameter
batchSize = 10
squeezedim = 16
training_Epoch = 10000

# placeholders for input of encoder and decoder
encoder_input = tf.placeholder(tf.float32,shape=[None, sentences_len, no_tokens])
x_real = tf.placeholder(tf.float32, shape=[None, sentences_len, no_tokens])

encoder_output = encoder(encoder_input,batchSize, no_tokens, squeezedim)
decoder_output = decoder(encoder_output,batchSize, squeezedim, no_tokens)

ae_loss = tf.reduce_mean(tf.pow(decoder_output-x_real,2))
train_en = tf.train.AdamOptimizer().minimize(ae_loss)
idx = np.arange(train_x.shape[0])
saver = tf.train.Saver()

with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())
    total_batch = int(train_x.shape[0]/batchSize)

    for epoch in range(training_Epoch):
        train_loss = []``
        for i in range(total_batch):
            batchIdx = np.random.choice(idx, size=batchSize, replace=False)
            r_x = train_x[batchIdx]
            c_x = c_train_x[batchIdx]
            _, c = sess.run([train_en, ae_loss], feed_dict={x_real:r_x, encoder_input:c_x})
            train_loss.append(c)
        print 'Epoch :- ',(epoch+1),' AutoEncoder Loss', np.mean(train_loss)

        # if epoch%1000==0:
        #     idx_temp = np.arange(test_x.shape[0])
        #     batchIdx = np.random.choice(idx_temp, size=batchSize, replace=False)
        #     saver.save(sess, 'model/my_test_model',global_step=epoch)
        #     # saver = tf.train.import_meta_graph('model/my_test_model-20100.meta')
        #     # saver.restore(sess,tf.train.latest_checkpoint('model/'))
        #     r_x = test_x[:batchSize]
        #     c_x = c_test_x[:batchSize]
        #     decoded = sess.run([decoder_output],feed_dict={encoder_input:c_x})
        #
        #     with open('output.txt','a') as outputfile:
        #         outputfile.write('######################## Epoch : '+str(epoch)+' ######################'+'\n\n')
        #         for check in range(batchSize):
        #             org=''
        #             for i in range(r_x.shape[1]):
        #                 temp = np.where(r_x[check][i]==1)[0][0]
        #                 org = org + id2word[temp] + ' '
        #             print 'original :- ', org
        #
        #             cor=''
        #             for i in range(c_x.shape[1]):
        #                 try:
        #                     temp = np.where(c_x[check][i]==1)[0][0]
        #                     cor = cor + id2word[temp] + ' '
        #                 except:
        #                     cor = cor + '<unk>' + ' '
        #             print 'corrupted :- ', cor
        #
        #             predicted=''
        #             for i in range(decoded[0].shape[1]):
        #                 temp = np.where(decoded[0][check][i]==max(decoded[0][check][i]))[0][0]
        #                 predicted = predicted + id2word[temp] + ' '
        #             print 'predicted :- ', predicted
        #
        #             outputfile.write('original sentence :- '+org+'\n')
        #             outputfile.write('corrupted sentence :- '+cor+'\n')
        #             outputfile.write('predicted sentence :- '+predicted+'\n\n')

    dictionary = {}
    total_batch = int(test_x.shape[0]/batchSize)
    j = 0
    for i in range(total_batch):
        r_x = test_x[j:(j+batchSize)]
        c_x = c_test_x[j:(j+batchSize)]
        decoded = sess.run([decoder_output],feed_dict={encoder_input:c_x})
        j = j + batchSize

        for check in range(batchSize):
            index = -1
            for k in range(c_x.shape[1]):
                try:
                    temp = np.where(c_x[check][k]==1)[0][0]
                except:
                    index = k
                    break

            org_index = np.where(r_x[check][index]==1)[0][0]
            pre_index = np.where(decoded[0][check][index]==max(decoded[0][check][index]))[0][0]
            print id2word[org_index], id2word[pre_index]

            if (id2word[org_index],id2word[pre_index]) in dictionary.keys():
                dictionary[id2word[org_index],id2word[pre_index]] += 1
            else:
                dictionary[id2word[org_index],id2word[pre_index]] = 1

    print dictionary
