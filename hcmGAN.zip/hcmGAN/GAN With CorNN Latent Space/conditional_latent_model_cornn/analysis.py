import numpy as np
import matplotlib.pyplot as plt

decloss_latent_model = np.load('gan_dic_loss.npy')
plt.plot(decloss_latent_model)
plt.xlabel('Epoch')
plt.ylabel('Descriminator Loss')
plt.savefig('Discriminator_Loss.png')
plt.show()

genloss_latent_model = np.load('gan_gen_loss.npy')
plt.plot(genloss_latent_model)
plt.xlabel('Epoch')
plt.ylabel('Generator Loss')
plt.savefig('Generator_Loss.png')
plt.show()

genloss = np.load('cornn_loss.npy')
plt.plot(genloss)
plt.xlabel('Epoch')
plt.ylabel('Autoencoder Loss')
plt.savefig('Autoencoder_Loss.png')
plt.show()