import numpy as np

generated = np.load('result_skill/generatedData.npy')
label_input = np.load('result_skill/auxData.npy')
threshold = 0.4

# take skill dictionary
skills = np.load('./../data/skill_dict.npy')
# profession vector which we have taken as a labels
prof = ['application developer','web designer','net developer','java developer','application support analyst','applications engineer']
# Open file to write generated data
file_d = open('result_skill/correlation.txt','w')
# Output of all sample
for i in range(generated.shape[0]):
	max_ind = list(label_input[i]).index(max(list(label_input[i])))
	file_d.write('profession :- '+prof[max_ind]+'\n')
	gen_str = ''
	for j in range(len(skills)):
		if generated[i][j]>=threshold:
			gen_str += str(skills[j])+', '
	file_d.write('generate data :- '+gen_str+'\n\n')
file_d.close()
