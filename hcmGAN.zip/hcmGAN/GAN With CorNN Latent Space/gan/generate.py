import os
import numpy as np
import matplotlib.pyplot as plt

if os.path.exists("result/generatedData.npy"):
    data = np.load("result/generatedData.npy")

    if not os.path.exists("result/generated"):
        os.makedirs("result/generated")

    for i in range(data.shape[0]):
        plt.imshow(np.reshape(data[i], (28,28)), cmap="gray")
        plt.savefig("result/generated/epoch_"+str(i)+".png", bbox_inches="tight")
else:
    print "Generated data not exist"