####################################################################################
########### Correlational Neural Network
########### Model

# Python dependancies
import os
import random
import matplotlib
import argparse
import numpy as np
import tensorflow as tf
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from tensorflow.contrib.layers import l2_regularizer, xavier_initializer, batch_norm

def spliter(mat, ratio):
    dim = mat.shape[1]
    left = int(dim*ratio)
    left_mat = mat[:, :left]
    right_mat = mat[:, left:]
    return left_mat, right_mat

# Class correlational neural network
class corNN(object):
    def __init__(self,
                datatype="binary",
                leftViewDim=392,
                rightViewDim=392,
                latent_space_dim=100,
                encoder_activation=tf.nn.tanh,
                l2_scale=0.0001,
                learning_rate=0.0005):

        # Parameter Initialization
        self.datatype = datatype
        # L2 Regularizer Parameter
        self.l2_scale = l2_scale
        # Learning rate of optimizer
        self.learning_rate = learning_rate
        # Dimension of left view
        self.leftDim = leftViewDim
        # Dimension of right view
        self.rightDim = rightViewDim
        # latent space dimentions( which is output of encoder )
        self.latent_space_dim = latent_space_dim
        # Activation Functions for Encoder
        self.encoder_activation = encoder_activation
        # Activation function for decoder
        if datatype=="binary":
            self.decoder_activation = tf.nn.sigmoid
        else:
            self.decoder_activation = tf.nn.relu

        self.initializer = xavier_initializer()

        print "Correlational autoencoder parameter initialized..."

    def cornnEnc(self, left_input, right_input, reuse=False):
        temp_left = left_input
        temp_right = right_input
        with tf.variable_scope("cornn_enc", reuse=reuse, regularizer=l2_regularizer(self.l2_scale)):
            # Linear model weights and bias initialization
            W = tf.get_variable('corNN_enc_W1', shape=[self.leftDim, self.latent_space_dim])  # dim = d1 * k
            V = tf.get_variable('corNN_enc_V1', shape=[self.rightDim, self.latent_space_dim]) # dim = d2 * k
            b = tf.get_variable('corNN_enc_b1', shape=[self.latent_space_dim]) # dim = k
            # Functional mapping to latent space
            h_x = tf.matmul(temp_left, W) # dim = batchsize * k
            h_y = tf.matmul(temp_right, V) # dim = batchsize * k
            h_z = self.encoder_activation(h_x + h_y + b)# dim = batchsize * k
            return h_x, h_y, h_z
        
    def cornnDec(self, x_latent, reuse=False):
        temp_latent = x_latent
        with tf.variable_scope("cornn_dec", reuse=reuse, regularizer=l2_regularizer(self.l2_scale)):
            # Linear model weights and bias initialization
            W_hat = tf.get_variable('corNN_dec_W1', shape=[self.latent_space_dim, self.leftDim]) # dim = k * d1
            V_hat = tf.get_variable('corNN_dec_V1', shape=[self.latent_space_dim, self.rightDim]) # dim = k * d2
            b_hat = tf.get_variable('corNN_dec_b1', shape=[self.leftDim + self.rightDim]) # dim = d1 + d2
            # Functional mapping to latent space
            h_xhat = tf.matmul(temp_latent, W_hat) # dim = batchsize * d1
            h_yhat = tf.matmul(temp_latent, V_hat) # dim = batchsize * d2
            h_con = tf.concat([h_xhat, h_yhat], 1) # dim = batchsize * (d1+d2)
            z_hat = self.decoder_activation(tf.add(h_con, b_hat)) # dim = batchsize * (d1+d2)
            return z_hat

    def cornn(self, left_input, right_input, reuse=False):
        '''
        Correlational Neural Network:
        Input:
            If input data has N features then N/2 feature will be provided as left_view
            and remaining features are provided has right_view
            1. left_view : half of input data
               right_view : other half of input data
        Output:
            1. z_hat : reconstructed data of length N
            2. h_x : latent representation of left view
            3. h_y : latent representation of right view
        '''
        h_x, h_y, h_z = self.cornnEnc(left_input, right_input, reuse=reuse)
        z_hat = self.cornnDec(h_z, reuse=reuse)
        return z_hat, h_x, h_y

    def train(self,
            data_path,
            noEpochs=200,
            batch_size=100,
            split_ratio=0.8,
            saveMaxKeep=0):
        # Load input data
        feature_mat = np.load(data_path)

        # Number of samples into dataset
        noSamples = feature_mat.shape[0]

        # Shuffle data
        shuffle_index = np.arange(noSamples)
        np.random.shuffle(shuffle_index)
        feature_mat = feature_mat[shuffle_index]

        # training data samples
        train_samples = int(noSamples*split_ratio)

        # Create training and testing data
        x_train = feature_mat[:train_samples]
        x_test = feature_mat[train_samples:]

        # Divided into two parts
        left_mat, right_mat = spliter(x_train, 0.5)
        left_test_mat, right_test_mat = spliter(x_test, 0.5)

        # Creater placeholders
        x_left_view = tf.placeholder(tf.float32,[None, self.leftDim])
        x_right_view = tf.placeholder(tf.float32, [None, self.rightDim])

        # Model
        x_recon, x_left_latent, x_right_latent = self.cornn(x_left_view, x_right_view)
        x_recon_left, _, _ = self.cornn(x_left_view, tf.zeros_like(x_right_view), reuse=True)
        x_recon_right, _, _ = self.cornn(tf.zeros_like(x_left_view), x_right_view, reuse=True)

        # Loss functions
        x_raw = tf.concat([x_left_view, x_right_view], 1)

        if self.datatype=="binary":
            recon_loss = tf.reduce_mean(-tf.reduce_sum(x_raw * tf.log(x_recon + 1e-12) \
                                                       + (1. - x_raw) * tf.log(1. - x_recon + 1e-12), 1), 0)
            recon_left_loss = tf.reduce_mean(-tf.reduce_sum(x_raw * tf.log(x_recon_left + 1e-12) \
                                                            + (1. - x_raw) * tf.log(1. - x_recon_left + 1e-12), 1), 0)
            recon_right_loss = tf.reduce_mean(-tf.reduce_sum(x_raw * tf.log(x_recon_right + 1e-12) \
                                                             + (1. - x_raw) * tf.log(1. - x_recon_right + 1e-12), 1), 0)
        else:
            recon_loss = tf.reduce_mean((x_raw - x_recon)**2)
            recon_left_loss = tf.reduce_mean((x_raw - x_recon_left)**2)
            recon_right_loss = tf.reduce_mean((x_raw - x_recon_right)**2)

        # Find correlation between latent space
        norm_x = x_left_latent - tf.reduce_mean(x_left_latent, axis=0)
        norm_y = x_right_latent - tf.reduce_mean(x_right_latent, axis=0)
        sq_norm_hx = tf.reduce_sum(norm_x ** 2)
        sq_norm_hy = tf.reduce_sum(norm_y ** 2)
        latent_loss = tf.reduce_sum(tf.matmul(norm_x, tf.transpose(norm_y))) / (tf.sqrt(sq_norm_hx * sq_norm_hy))

        # Total loss
        total_loss = recon_loss + recon_left_loss + recon_right_loss - latent_loss

        # pool out trainable variables for optimization
        cornnEnc_vars =  tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope="cornn_enc")
        cornnDec_vars = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope="cornn_dec")
        all_regs = tf.get_collection(tf.GraphKeys.REGULARIZATION_LOSSES)
        optimize = tf.train.AdamOptimizer(learning_rate=self.learning_rate).\
                    minimize(total_loss+sum(all_regs), var_list=cornnEnc_vars+cornnDec_vars)
        initOp = tf.global_variables_initializer()

        if not os.path.exists('result'):
            os.makedirs('result')

        # No of training batches
        noBatches = int(left_mat.shape[0]/batch_size)
        idx = np.arange(left_mat.shape[0])
        print "No of Training epochs: ", noEpochs
        print "No of batches: ", noBatches
        with tf.Session() as sess:
            sess.run(initOp)
            cornn_loss = []
            for epoch in range(noEpochs):
                batchidx = np.random.choice(idx, size=batch_size, replace=False)
                left_view, right_view = left_mat[batchidx], right_mat[batchidx]
                _, loss = sess.run([optimize, total_loss], feed_dict={x_left_view:left_view, x_right_view:right_view})
                print 'Epoch:- ',epoch,', Reconstruction Loss:- ', loss
                cornn_loss.append(loss)

                if epoch%25==0:
                    random_index = random.randint(1, left_test_mat.shape[0]-1)
                    left_data = left_test_mat[random_index-1:random_index]
                    right_data = np.zeros([1, self.rightDim])
                    generated = sess.run(x_recon, feed_dict={x_left_view:left_data, x_right_view:right_data})
                    plt.imshow(np.reshape(generated, (28,28)), cmap="gray")
                    plt.savefig('result/epoch_'+str(epoch)+'.png')

            np.save('result/cornn_loss.npy', cornn_loss)

def parse_arguments(parser):
	parser.add_argument('data_type', type=str, metavar='<data_type>', choices=['binary', 'count'], help='Data Type of input data...Binary/Count')
	parser.add_argument('data_path', type=str, metavar='<data_matrix>', help='Path to Data Matrix')
	parser.add_argument('--batch_size', type=int, default=64, help='batch-size')
	parser.add_argument('--latent_space_dim', type=int, default=100, help='Dimention of compressed data(output of encoder)')
	parser.add_argument('--noEpochs', type=int, default=100000, help='No of epochs to train the model')
	args = parser.parse_args()
	return args

if __name__=="__main__":
	parser = argparse.ArgumentParser()
	args = parse_arguments(parser)
	data = np.load(args.data_path)
	inputDim = data.shape[1]
	cornn = corNN(datatype=args.data_type, latent_space_dim=100)
	cornn.train(data_path=args.data_path, noEpochs=args.noEpochs, batch_size=args.batch_size)