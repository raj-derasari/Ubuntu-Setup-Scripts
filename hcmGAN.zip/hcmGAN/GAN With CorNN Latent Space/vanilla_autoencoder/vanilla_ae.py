####################################################################################
########### Vanilla Autoencoder
# References: Implementation:- (https://towardsdatascience.com/deep-inside-autoencoders-7e41f319999f)
########### Model
## 1. Encoder: 
# 			Objective: Take real time high dimention data (continuous/discrete) and map into small dimentions.
#                      Mapping into latent space.
# 			Design:	for number_of_hidden_layers:
# 						1. Linear Modeling with weights and bias
#						3. Non-linear activation function (relu)
#					# output Layer
#					1. Linear Modeling with weights and bias
#					2. Non-linear output activation function 
# 						(assign according to data representative you want)
#			Output: Latent space representation (batch_size, latent_space_dim)
#
## 2. Decoder: 
# 			Objective: Take output of encoder and reconstruct the original data from latent space.
# 			Design:	for number_of_hidden_layers:
# 						1. Linear Modeling with weights and bias
#						3. Non-linear activation function (relu)
#					# output Layer
#					1. Linear Modeling with weights and bias
#					2. Non-linear output activation function 
#                       (According to data representation...select activation functions)
#			Output: Reconstructed data

# Python dependancies
import os
import random
import matplotlib
import argparse
import numpy as np
import tensorflow as tf
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from tensorflow.contrib.layers import l2_regularizer, xavier_initializer, batch_norm

# Class Vanilla Autoencoder
class vanilla_ae(object):
    def __init__(self,
                datatype="binary",
                latent_space_dim=100,
                dataDim=784,
                encoder_hidden_dim=(800,400),
                decoder_hidden_dim=(400,800,1000),
                encoder_activation=tf.nn.sigmoid,
                l2_scale=0.0001,
                learning_rate=0.0005):

        # Parameter Initialization
        self.datatype = datatype
        # L2 Regularizer Parameter
        self.l2_scale = l2_scale
        # Learning rate of optimizer
        self.learning_rate = learning_rate
        # inputDim and outputDim
        self.dataDim = dataDim
        # latent space dimentions( which is output of encoder )
        self.latent_space_dim = latent_space_dim
        # hidden layer dimentions for encoder
        self.encoder_hidden_dim = list(encoder_hidden_dim)
        # hidden layer dimentions for decoder
        self.decoder_hidden_dim = list(decoder_hidden_dim)
        # Activation Functions for Encoder
        self.encoder_activation = encoder_activation
        # hidden layer activation functions for encoder
        self.hid_encoder_activation = tf.nn.relu
        # hidden layer activation functions for decoder
        self.hid_decoder_activation = tf.nn.relu
        # Activation function for decoder
        if datatype=="binary":
            self.decoder_activation = tf.nn.sigmoid
        else:
            self.decoder_activation = tf.nn.relu

        self.initializer = xavier_initializer()

        # Dictionary to store encoder and decoder learning parameter
        self.encoderVariables={}
        self.decoderVariables={}
        print "vanilla autoencoder parameter initialized..."

    def encoder(self, input_x, reuse=False):
        '''
        Encoder:
        Input:
            1. input_x : input data
                       : 2-D data (binary or continuous)
        Output:
            1. out_enc : latent space representation of input data
                       : 2-D data (continuous)
        '''
        temp_vec = input_x
        temp_dim = self.dataDim
        with tf.variable_scope('Encoder', reuse=reuse, regularizer=l2_regularizer(self.l2_scale)):
            i = 0
            for _ in range(len(self.encoder_hidden_dim)):
                # Initialize encoder weights and bias
                W = tf.get_variable('enc_hW'+str(i), shape=[temp_dim, self.encoder_hidden_dim[i]], initializer=self.initializer)
                b = tf.get_variable('enc_hb'+str(i), shape=[self.encoder_hidden_dim[i]], initializer=self.initializer)
                # Store encoder weights and bias
                self.encoderVariables['enc_hW'+str(i)]=W
                self.encoderVariables['enc_hb'+str(i)]=b
                # Apply activation function
                h = self.hid_encoder_activation(tf.matmul(temp_vec, W)+b)
                # Store intermediate result for next interation
                temp_vec, temp_dim, i = h, self.encoder_hidden_dim[i], i+1
            # Encoder Output Layer
            W = tf.get_variable('enc_oW'+str(i), shape=[temp_dim, self.latent_space_dim], initializer=self.initializer)
            b = tf.get_variable('enc_ob'+str(i), shape=[self.latent_space_dim], initializer=self.initializer)
            self.encoderVariables['enc_oW'+str(i)]=W
            self.encoderVariables['enc_ob'+str(i)]=b
            out_enc = self.encoder_activation(tf.matmul(temp_vec, W)+b)
            return out_enc

    def decoder(self, latent_x, reuse=False):
        '''
        Decoder:
        Input:
            1. latent_x : latent space output of encoder
                        : 2-D data (continuous)
        Output:
            1. out_dec : reconstructed data from latent space data
                       : 2-D data (continuous)
        '''
        temp_vec = latent_x
        temp_dim = self.latent_space_dim
        with tf.variable_scope('Decoder', reuse=reuse, regularizer=l2_regularizer(self.l2_scale)):
            i = 0
            # Hidden Layers
            for _ in range(len(self.decoder_hidden_dim)):
                # Get or initialize variable
                W = tf.get_variable('dec_hW'+str(i), shape=[temp_dim, self.decoder_hidden_dim[i]], initializer=self.initializer)
                b = tf.get_variable('dec_hb'+str(i), shape=[self.decoder_hidden_dim[i]], initializer=self.initializer)
                self.decoderVariables['dec_hW'+str(i)]=W
                self.decoderVariables['dec_hb'+str(i)]=b
                # Decoder hidden layer activation
                h = self.hid_decoder_activation(tf.matmul(temp_vec, W)+b)
                temp_vec, temp_dim, i = h, self.decoder_hidden_dim[i], i+1
            # Decoder Output layer
            W = tf.get_variable('dec_oW'+str(i), shape=[temp_dim, self.dataDim], initializer=self.initializer)
            b = tf.get_variable('dec_ob'+str(i), shape=[self.dataDim], initializer=self.initializer)
            self.decoderVariables['dec_oW'+str(i)]=W
            self.decoderVariables['dec_ob'+str(i)]=b
            out_dec = self.decoder_activation(tf.matmul(temp_vec, W)+b)
            return out_dec

    def train(self,
            data_path,
            noEpochs=200,
            batch_size=100,
            split_ratio=0.8,
            saveMaxKeep=0):
        # Load input data
        feature_mat = np.load(data_path)

        # Number of samples into dataset
        noSamples = feature_mat.shape[0]

        # Shuffle data
        shuffle_index = np.arange(noSamples)
        np.random.shuffle(shuffle_index)
        feature_mat = feature_mat[shuffle_index]

        # training data samples
        train_samples = int(noSamples*split_ratio)

        # Create training and testing data
        x_train = feature_mat[:train_samples]
        x_test = feature_mat[train_samples:]

        # Creater placeholders
        x_raw = tf.placeholder(tf.float32,[None, self.dataDim])

        # Model
        x_latent = self.encoder(x_raw)
        x_generated = self.decoder(x_latent)

        # Create loss function
        if self.datatype=="binary":
            loss_ae = tf.reduce_mean(-tf.reduce_sum(x_raw * tf.log(x_generated + 1e-12) \
                        + (1. - x_raw) * tf.log(1. - x_generated + 1e-12), 1), 0)
        else:
            loss_ae = tf.reduce_sum((x_raw - x_generated)**2)

        # pool out trainable variables for optimization
        encoder_vars =  tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope="Encoder")
        decoder_vars =  tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope="Decoder")
        all_regs = tf.get_collection(tf.GraphKeys.REGULARIZATION_LOSSES)
        optimize = tf.train.AdamOptimizer(learning_rate=self.learning_rate).\
                    minimize(loss_ae+sum(all_regs), var_list=encoder_vars+decoder_vars)

        initOp = tf.global_variables_initializer()

        if not os.path.exists('ae_result'):
            os.makedirs('ae_result')

        # No of training batches
        noBatches = int(x_train.shape[0]/batch_size)
        print "No of Training epochs: ", noEpochs
        print "No of batches: ", noBatches
        with tf.Session() as sess:
            sess.run(initOp)
            autoencoder_loss = []
            for epoch in range(noEpochs):
                ae_loss, i = [], 0
                for _ in range(noBatches):
                    input_batch = x_train[i:i+batch_size]
                    _, loss = sess.run([optimize, loss_ae], feed_dict={x_raw:input_batch})
                    ae_loss.append(loss)
                    i = i + batch_size
                print 'Epoch:- ',epoch,', Reconstruction Loss:- ', np.mean(ae_loss)
                autoencoder_loss.append(np.mean(ae_loss))

                idx = np.arange(x_test.shape[0])
                if epoch%25==0:
                    batchIdx = np.random.choice(idx, size=batch_size, replace=False)
                    test_data = x_test[batchIdx]
                    generated = sess.run(x_generated, feed_dict={x_raw: test_data})
                    np.save('ae_result/epoch_'+str(epoch)+'.npy', generated)

            np.save('ae_result/ae_loss.npy', autoencoder_loss)

def parse_arguments(parser):
	parser.add_argument('data_type', type=str, metavar='<data_type>', choices=['binary', 'count'], help='Data Type of input data...Binary/Count')
	parser.add_argument('data_path', type=str, metavar='<data_matrix>', help='Path to Data Matrix')
	parser.add_argument('--batch_size', type=int, default=100, help='batch-size')
	parser.add_argument('--latent_space_dim', type=int, default=100, help='Dimention of compressed data(output of encoder)')
	parser.add_argument('--noEpochs', type=int, default=200, help='No of epochs to train the model')
	args = parser.parse_args()
	return args

if __name__=="__main__":
	parser = argparse.ArgumentParser()
	args = parse_arguments(parser)
	data = np.load(args.data_path)
	inputDim = data.shape[1]
	vae = vanilla_ae(datatype=args.data_type, dataDim=inputDim, latent_space_dim=100)
	vae.train(data_path=args.data_path, noEpochs=args.noEpochs, batch_size=args.batch_size)