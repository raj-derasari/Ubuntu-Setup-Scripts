####################################################################################
########### Conditional Generative Adversarial Network 
# References: Paper:- (https://arxiv.org/abs/1411.1784)
########### Model
## 1. Generator: 
# 			Objective: Generator will take random noise as input and feature vector on which you want to condition 
# 					   the data and try to generate data of dimention {dataDim}.
# 			Design:	Concate input noise and conditional feature vector
#					for number_of_hidden_layers:
# 						1. Linear Modeling with weights and bias
#						2. Apply batch normalization scale*(data - mean)/var + offset
#						3. Non-linear activation function (relu)
#					# output Layer
#					1. Linear Modeling with weights and bias
#					2. Non-linear output activation function 
# 						(assign according to data representative you want)
#			Output: Generates data of (batch_size,dataDim)
#
## 2. Discriminator: 
# 			Objective: Try to discriminate whether data which is fed into it, 
# 					   is real or synthetic(given conditional feature vector).
# 			Design:	Concate input vector and conditional feature vector
# 					for number_of_hidden_layers:
# 						1. Linear Modeling with weights and bias
#						3. Non-linear activation function (leaky-relu...recommended)
#					# output Layer
#					1. Linear Modeling with weights and bias
#					2. Non-linear output activation function 
# 						(if you want to use...use sigmoid)
#			Output: Outputs scaler between 0 and 1 which shows probability of generated 
# 					data is real or synthetic

# Python dependancies
import os						# For creating directories
import random					# For random number or vector generation
import numpy as np				# For matrix related work
import tensorflow as tf			# Generative Model implementation, optimization and generation
import matplotlib				# For storing images
import argparse
matplotlib.use('Agg')			
import matplotlib.pyplot as plt

# To import xavier_initializer for initialization of weights (Recommended)
# Blog for ref: http://andyljones.tumblr.com/post/110998971763/an-explanation-of-xavier-initialization
from tensorflow.contrib.layers import xavier_initializer

# Class CGAN
class CGAN(object):
	def __init__(self,
				dataDim=784,
				auxDataDim=10,
				noiseDim=32,
				generator_hidden_dim=(128,256,512),
				discriminator_hidden_dim=(256,128,64,32),
				generator_activation=tf.nn.sigmoid,
				CRITIC_LEARNING_RATE=0.001,
				GEN_LEARNING_RATE=0.001):
		################################## Parameter Initialization
		# Noise dimention (Input of generator)
		self.noiseDim = noiseDim
		# Input Data Dimention
		self.dataDim = dataDim
		# Auxiliary data dimensions
		self.auxDataDim = auxDataDim
		# Generator hidden layer dimentions
		self.generator_hidden_dim = list(generator_hidden_dim)
		# Discriminator hidden layer dimentions
		self.discriminator_hidden_dim = list(discriminator_hidden_dim)
		# Learning rate of discriminator
		self.CRITIC_LEARNING_RATE = CRITIC_LEARNING_RATE
		# Learning rate of generator
		self.GEN_LEARNING_RATE = GEN_LEARNING_RATE
		# Activation Functions for Generator
		self.generator_activation = generator_activation
		# Activation function for Discriminator (One can use sigmoid)
		self.discriminator_activation = tf.identity
		# Default weights initializer
		self.initializer = xavier_initializer()
		print "CGAN parameter initialized..."

	############ Leaky relu non-linear activation functions
	def leaky_relu(self, x, alpha):
		return (tf.nn.relu(x) - (alpha * tf.nn.relu(-x)))

	############ Batch Normalization (One kind of regularizer)
	# Blog for ref: https://towardsdatascience.com/batch-normalization-in-neural-networks-1ac91516821c
	def batch_norm(self, x, dim):
		epsilon = 0.001
		# Find mean and varience of input data (x)
		mean, var = tf.nn.moments(x, axes=[0])
		# Return (scaler*(x-mean)/var)+offset (Here scaler will be 1 and offset is 0)
		return tf.nn.batch_normalization(x, mean, var, offset=tf.zeros([dim]), scale=tf.ones([dim]), variance_epsilon=epsilon)

	############ Generator
	def generator(self, z, input_y, reuse=False):
		temp_vec = tf.concat([z, input_y],1)
		temp_dim = self.noiseDim + self.auxDataDim
		with tf.variable_scope('Generator', reuse=reuse):
			i = 0
			# Hidden layer activation
			for dim in self.generator_hidden_dim:
				# Linear Modeling of hidden layer
				W = tf.get_variable('gen_hW'+str(i), shape=[temp_dim, dim], initializer=self.initializer)
				b = tf.get_variable('gen_hb'+str(i), shape=[dim], initializer=tf.constant_initializer([0]))
				_h = tf.matmul(temp_vec, W) + b
				# Apply batch normalization
				_h = self.batch_norm(_h, dim)
				# Apply non-linear activation function (relu)
				_h = tf.nn.relu(_h)
				temp_vec, temp_dim, i = _h, dim, i+1
			# Output Layer (generator output dim)
			W = tf.get_variable('gen_oW'+str(i), shape=[temp_dim, self.dataDim], initializer=self.initializer)
			b = tf.get_variable('gen_ob'+str(i), shape=[self.dataDim], initializer=tf.constant_initializer([0]))
			h = self.generator_activation(tf.matmul(temp_vec, W)+b)
			return h
	
	############# Discriminator
	def discriminator(self, input_x, input_y, reuse=False):
		temp_vec = tf.concat([input_x, input_y],1)
		temp_dim = self.dataDim + self.auxDataDim
		with tf.variable_scope('Discriminator', reuse=reuse):
			i = 0
			# Hidden layer activation			
			for _, dim in enumerate(self.discriminator_hidden_dim):
				# Linear Modeling of hidden layer
				W = tf.get_variable('dic_hW'+str(i), shape=[temp_dim, dim], initializer=self.initializer)
				b = tf.get_variable('dic_hb'+str(i), shape=[dim], initializer=tf.constant_initializer([0]))
				_h = tf.matmul(temp_vec, W) + b
				# Apply non-linear activation function (leaky relu)
				_h = self.leaky_relu(_h, 0.2)
				temp_vec, temp_dim, i = _h, dim, i+1
			# Output Layer (scaler)
			W = tf.get_variable('dic_oW'+str(i), shape=[temp_dim, 1], initializer=self.initializer)
			b = tf.get_variable('dic_ob'+str(i), shape=[1], initializer=tf.constant_initializer([0]))
			h = self.discriminator_activation(tf.matmul(temp_vec, W)+b)
			return h

	############ Trainging of CGAN
	def train(self, 					#######################################################################
			data_matrix, 				# Provide data matrix
			aux_matrix,					# Provide auxiliary data matrix (on which you want to condition)
			model_file, 				# Model file name
			noEpochs=1500, 				# Number of training epochs
			batch_size=100, 			# Batch size
			discriminator_update=1, 	# Discriminator updates
			generator_update=1,			# Generator updates
			saveMaxKeep=0): # How many models you want to save (0 means it will keep all the models)

		if data_matrix.shape[0]!=aux_matrix.shape[0] or data_matrix.shape[1]!=self.dataDim or aux_matrix.shape[1]!=self.auxDataDim:
			return False

		# Number of samples into dataset
		noSamples = data_matrix.shape[0]

		# Shuffle data
		shuffle_index = np.arange(noSamples)
		np.random.shuffle(shuffle_index)
		feature_mat = data_matrix[shuffle_index]
		aux_matrix = aux_matrix[shuffle_index]

		# Create training and testing data
		x_train = np.copy(feature_mat)
		y_train = np.copy(aux_matrix)

		# Creater placeholders
		z_noise = tf.placeholder(tf.float32,[None, self.noiseDim])
		x_raw = tf.placeholder(tf.float32,[None, self.dataDim])
		y_raw = tf.placeholder(tf.float32,[None, self.auxDataDim])

		# Model with generator and discriminator function
		x_generated = self.generator(z_noise, y_raw)
		y_real_predicted = self.discriminator(x_raw, y_raw)
		y_fake_predicted = self.discriminator(x_generated, y_raw, reuse=True)

		# Create loss functions
		loss_d_real = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=y_real_predicted, labels=tf.ones_like(y_real_predicted)))
		loss_d_fake = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=y_fake_predicted, labels=tf.zeros_like(y_fake_predicted)))
		loss_d = loss_d_fake + loss_d_real
		loss_g = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=y_fake_predicted, labels=tf.ones_like(y_fake_predicted)))

		# pool out trainable variables for optimization
		generator_vars = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope="Generator")
		dicriminator_vars = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope="Discriminator")
		optimize_d = tf.train.AdamOptimizer(learning_rate=self.CRITIC_LEARNING_RATE).minimize(loss_d, var_list=dicriminator_vars)
		optimize_g = tf.train.AdamOptimizer(learning_rate=self.GEN_LEARNING_RATE).minimize(loss_g, var_list=generator_vars)

		# Global variable initialize
		initOp = tf.global_variables_initializer()
		noBatches = int(x_train.shape[0]/batch_size)
		idx = np.arange(x_train.shape[0])
		saver = tf.train.Saver(max_to_keep=saveMaxKeep)
		random.seed(1234)
		print "No of training epochs: ",noEpochs
		print "No of batches: ",noBatches
		with tf.Session() as sess:
			sess.run(initOp)
			generator_loss, discriminator_loss = [], []
			for epoch in range(noEpochs):
				gen_loss, dic_loss = [], []
				for _ in range(noBatches):
					# Train Discriminator
					for _ in range(discriminator_update):
						batchIdx = np.random.choice(idx, size=batch_size, replace=False)
						input_batch = x_train[batchIdx]
						y_batch = y_train[batchIdx]
						randomX = np.random.normal(size=(batch_size, self.noiseDim))
						_, dloss = sess.run([optimize_d, loss_d], feed_dict={z_noise:randomX, x_raw:input_batch, y_raw:y_batch})
						dic_loss.append(dloss)
					# Train Generator
					for _ in range(generator_update):
						batchIdx = np.random.choice(idx, size=batch_size, replace=False)
						y_batch = y_train[batchIdx]
						randomX = np.random.normal(size=(batch_size, self.noiseDim))
						_, gloss = sess.run([optimize_g, loss_g], feed_dict={z_noise:randomX, y_raw:y_batch})
						gen_loss.append(gloss)

				avg_generator = np.mean(gen_loss)
				avg_discriminator = np.mean(dic_loss)
				print 'Epoch:- ',epoch,', Discriminator Loss:- ', avg_discriminator,', Generator Loss:- ', avg_generator
				generator_loss.append(avg_generator)
				discriminator_loss.append(avg_discriminator)
				savePath = saver.save(sess, str(model_file), global_step=epoch)
	
			np.save('cgan_dic_loss.npy', discriminator_loss)
			np.save('cgan_gen_loss.npy', generator_loss)

	def generateData(self, 
					aux_matrix,
					model_file,
					noSamples=100, 
					batch_size=100):
		# Check dimension constraints
		if aux_matrix.shape[1]!=self.auxDataDim:
			return False

		# Load data
		y_train = np.copy(aux_matrix)

		# Creater placeholders
		z_noise = tf.placeholder(tf.float32,[None, self.noiseDim])
		y_raw = tf.placeholder(tf.float32,[None, self.auxDataDim])

		# Model with generator and discriminator function
		x_generated = self.generator(z_noise, y_raw)

		if not os.path.exists('result'):
			os.makedirs('result')
			
		saver = tf.train.Saver()
		idx = np.arange(aux_matrix.shape[0])
		random.seed(1234)
		with tf.Session() as sess:
			saver.restore(sess, model_file)
			for _ in range(1000):
				# Burning Generator
				batchIdx = np.random.choice(idx, size=batch_size, replace=False)
				y_batch = y_train[batchIdx]
				randomX = np.random.normal(size=(batch_size, self.noiseDim))
				sess.run(x_generated, feed_dict={z_noise:randomX, y_raw:y_batch})
			# Generate Data
			randomX = np.random.normal(size=(noSamples, self.noiseDim))
			batchIdx = np.random.choice(idx, size=noSamples, replace=False)
			y_batch = y_train[batchIdx]
			generated = sess.run(x_generated, feed_dict={z_noise:randomX, y_raw:y_batch})
			np.save('result/generatedData.npy', generated)
			np.save('result/auxData.npy', y_batch)

def parse_arguments(parser):
	parser.add_argument('action', type=str, metavar='<action>', choices=['train', 'generate'], help='Train or Generate data')
	parser.add_argument('data_file', type=str, metavar='<data_matrix>', help='Data Matrix')
	parser.add_argument('aux_data_file', type=str, metavar='<aux_data_matrix>', help='Auxiliary Data Matrix')
	parser.add_argument('model_file', type=str, metavar='<model_filename>', default='model', help='The path to the model file, in case you want to continue training. (default value: '')')
	parser.add_argument('--noise_dim', type=int, default=64, help='Noise dim which is input of generator')
	parser.add_argument('--discriminator_update', type=int, default=1, help='The number of times to update the discriminator per epoch. (default value: 2)')
	parser.add_argument('--generator_update', type=int, default=1, help='The number of times to update the generator per epoch. (default value: 1)')
	parser.add_argument('--batch_size', type=int, default=240, help='batch-size')
	parser.add_argument('--noEpochs', type=int, default=1000, help='No of epochs to train the model')
	parser.add_argument('--noSamples', type=int, default=100, help='No of samples, you want to generate')
	args = parser.parse_args()
	return args

## Run CGAN.py from console to debug the CGAN module. To train the model with Autoencoder, please run Train.py
if __name__=="__main__":
	parser = argparse.ArgumentParser()
	args = parse_arguments(parser)
	data = np.load(args.data_file)
	label = np.load(args.aux_data_file)
	model_file = args.model_file

	inputDim = data.shape[1]
	auxDim = label.shape[1]

	print("CGAN.py was run directly from console. Running CGAN.py for Debugging mode")
	cgan = CGAN(dataDim=inputDim, noiseDim=args.noise_dim)

	if args.action=="train":
		cgan.train(data_matrix=data,
				aux_matrix=label, 
				model_file=model_file,
				noEpochs=args.noEpochs,
				batch_size=args.batch_size,
				discriminator_update=args.discriminator_update,
				generator_update=args.generator_update)
	else:
		cgan.generateData(aux_matrix=label, model_file=model_file, noSamples=args.noSamples, batch_size=args.batch_size)