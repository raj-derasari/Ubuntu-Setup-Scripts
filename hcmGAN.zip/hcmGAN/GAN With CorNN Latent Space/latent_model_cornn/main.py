############################################################################
######### Correlational Neural Network + GAN
############################################################################

# Python Dependancies
import os
import sys
import shutil
import random
import argparse
import matplotlib
import numpy as np
import tensorflow as tf
from tensorflow.contrib.layers import l2_regularizer, xavier_initializer

matplotlib.use('Agg')
import matplotlib.pyplot as plt

sys.path.insert(0,'./../gan/')
sys.path.insert(0,'./../cornn/')

from gan import GAN
from cornn import corNN

def spliter(data_matrix, ratio, axis=0):
	if axis==0:
		no_columns = data_matrix.shape[1]
		left_matrix_dim = int(no_columns*ratio)
		left_mat = data_matrix[:, :left_matrix_dim]
		right_mat = data_matrix[:, left_matrix_dim:]
	else:
		no_rows = data_matrix.shape[0]
		upper_dim = int(no_rows*ratio)
		left_mat = data_matrix[:upper_dim, :]
		right_mat = data_matrix[upper_dim:, :]
	return left_mat, right_mat

class Latent_Model(object):
	def __init__(self, \
				datatype, \
				noiseDim=32, \
				left_view_dim=392, \
				right_view_dim=392, \
				latent_space_dim=100):
		############################################### Parameter Initialization
		# Check datatype of input data
		self.datatype = datatype
		# Input noise dimention of generator
		self.noiseDim = noiseDim
		# Latent space representation
		self.latent_space_dim = latent_space_dim
		# Left view dimension
		self.left_view_dim = left_view_dim
		# Right view dimension
		self.right_view_dim = right_view_dim
		# Create instance of Generative Adversarial Network
		self.gan_obj = GAN(dataDim=latent_space_dim, \
					noiseDim=noiseDim, \
					generator_hidden_dim=(64,100,150), \
					discriminator_hidden_dim=(100,60,20), \
					generator_activation=tf.nn.tanh)
		# Create instance of Vanilla cornn
		self.cornn_obj = corNN(datatype=datatype, \
							leftViewDim=left_view_dim, \
							rightViewDim=right_view_dim, \
							latent_space_dim=latent_space_dim, \
							encoder_activation=tf.nn.tanh)
		print "Instance initialized..."
	
	# Training of Model
	def train(self, 
			x_left, 				# Left view data matrix
			x_right, 				# Right view data matrix
			model_file,				# Model file name
			pre_training_epoch=150,	# pre-training epoch of cornn
			noEpochs=1000,			# Training epoch for GAN
			batch_size=240,			# Batch size
			generator_update=1,		# No of Generator updates
			discriminator_update=2, # No of discriminator updates
			saveMaxKeep=10):		# No of models... you want to save
		
		# Check dimensions
		if x_left.shape[1]!=self.left_view_dim or x_right.shape[1]!=self.right_view_dim or x_left.shape[0]!=x_right.shape[0]:
			return False

		# Placeholders
		z_noise = tf.placeholder('float',[None, self.noiseDim])
		x_left_view = tf.placeholder(tf.float32,[None, self.left_view_dim])
		x_right_view = tf.placeholder(tf.float32, [None, self.right_view_dim])

		####################################### Functions
		# [Correlational View Network]
		x_recon, x_left_latent, x_right_latent = self.cornn_obj.cornn(x_left_view, x_right_view)
		x_recon_left, _, _ = self.cornn_obj.cornn(x_left_view, tf.zeros_like(x_right_view), reuse=True)
		x_recon_right, _, _ = self.cornn_obj.cornn(tf.zeros_like(x_left_view), x_right_view, reuse=True)
		
		# [GAN]
		_, _, x_latent = self.cornn_obj.cornnEnc(x_left_view, x_right_view, reuse=True)
		syn_latent = self.gan_obj.generator(z_noise)
		y_hat_real = self.gan_obj.discriminator(x_latent)
		y_hat_fake = self.gan_obj.discriminator(syn_latent, reuse=True)

		# Loss functions
		x_raw = tf.concat([x_left_view, x_right_view], 1)

		if self.datatype=="binary":
			recon_loss = tf.reduce_mean(-tf.reduce_sum(x_raw * tf.log(x_recon + 1e-12) \
													   + (1. - x_raw) * tf.log(1. - x_recon + 1e-12), 1), 0)
			recon_left_loss = tf.reduce_mean(-tf.reduce_sum(x_raw * tf.log(x_recon_left + 1e-12) \
															+ (1. - x_raw) * tf.log(1. - x_recon_left + 1e-12), 1), 0)
			recon_right_loss = tf.reduce_mean(-tf.reduce_sum(x_raw * tf.log(x_recon_right + 1e-12) \
															 + (1. - x_raw) * tf.log(1. - x_recon_right + 1e-12), 1), 0)
		else:
			recon_loss = tf.reduce_mean((x_raw - x_recon)**2)
			recon_left_loss = tf.reduce_mean((x_raw - x_recon_left)**2)
			recon_right_loss = tf.reduce_mean((x_raw - x_recon_right)**2)

		# Find correlation between latent space
		norm_x = x_left_latent - tf.reduce_mean(x_left_latent, axis=0)
		norm_y = x_right_latent - tf.reduce_mean(x_right_latent, axis=0)
		sq_norm_hx = tf.reduce_sum(norm_x ** 2)
		sq_norm_hy = tf.reduce_sum(norm_y ** 2)
		latent_loss = tf.reduce_sum(tf.matmul(norm_x, tf.transpose(norm_y))) / (tf.sqrt(sq_norm_hx * sq_norm_hy))

		# Total loss of correlational neural network
		loss_cornn = recon_loss + recon_left_loss + recon_right_loss - latent_loss

		# Create loss functions
		loss_d_real = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=y_hat_real, labels=tf.ones_like(y_hat_real)))
		loss_d_fake = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=y_hat_fake, labels=tf.zeros_like(y_hat_fake)))
		loss_d = loss_d_fake + loss_d_real
		loss_g = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=y_hat_fake, labels=tf.ones_like(y_hat_fake)))

		# pool out trainable variables for optimization
		cornn_var =  tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope="cornn_enc") + \
						tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope="cornn_dec")
		gen_var = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope="Generator")
		dic_var = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope="Discriminator")
		all_regs = tf.get_collection(tf.GraphKeys.REGULARIZATION_LOSSES)

		# Optimization Functions
		optimize_cornn = tf.train.AdamOptimizer().minimize(loss_cornn + sum(all_regs), var_list=cornn_var)
		optimize_d = tf.train.AdamOptimizer().minimize(loss_d, var_list=dic_var)
		optimize_g = tf.train.AdamOptimizer().minimize(loss_g, var_list=gen_var)

		initOp = tf.global_variables_initializer()

		noBatches = int(x_left.shape[0]/batch_size)
		idx = np.arange(x_left.shape[0])
		saver = tf.train.Saver(max_to_keep=saveMaxKeep)
		random.seed(1234)
		with tf.Session() as sess:
			sess.run(initOp)
			# Pre-training of cornn
			cornn_loss, last_cornn_loss, epoch = [], -1, 0
			while True:
				temp_loss, i = [], 0
				for _ in range(noBatches):
					left_view, right_view = x_left[i:i+batch_size], x_right[i:i+batch_size]
					_, loss = sess.run([optimize_cornn, loss_cornn], feed_dict={x_left_view:left_view, x_right_view:right_view})
					temp_loss.append(loss)
					i+=batch_size
				avg_cornn_loss = np.mean(temp_loss)
				print "Epoch:"+str(epoch)+", cornn reconstruction loss: ", avg_cornn_loss
				cornn_loss.append(avg_cornn_loss)
				epoch += 1

				if last_cornn_loss<0 or abs((last_cornn_loss - avg_cornn_loss)/float(last_cornn_loss))>0.0001:
					last_cornn_loss = avg_cornn_loss
				else:
					break


			generator_loss, discriminator_loss = [], []
			for epoch in range(noEpochs):
				gen_loss, dic_loss = [], []
				for _ in range(noBatches):
					for _ in range(discriminator_update):
						batchIdx = np.random.choice(idx, size=batch_size, replace=False)
						left_view, right_view = x_left[batchIdx], x_right[batchIdx]
						randomX = np.random.normal(size=(batch_size, self.noiseDim))
						_, dloss = sess.run([optimize_d, loss_d], feed_dict={z_noise:randomX, x_left_view:left_view, x_right_view:right_view})
						dic_loss.append(dloss)

					for _ in range(generator_update):
						randomX = np.random.normal(size=(batch_size, self.noiseDim))
						_, gloss = sess.run([optimize_g, loss_g], feed_dict={z_noise:randomX})
						gen_loss.append(gloss)

				avg_generator = np.mean(gen_loss)
				avg_discriminator = np.mean(dic_loss)
				print 'Epoch:- ',epoch,', Discriminator Loss:- ', avg_discriminator,', Generator Loss:- ', avg_generator
				generator_loss.append(avg_generator)
				discriminator_loss.append(avg_discriminator)
				savePath = saver.save(sess, model_file, global_step=epoch)

			# Store all the losses
			np.save('gan_dic_loss.npy', discriminator_loss)
			np.save('gan_gen_loss.npy', generator_loss)
			np.save('cornn_loss.npy', cornn_loss)

	def generateData(self, model_file, batch_size=240, noSamples=10000):
		###################################### Placeholders
		z_noise = tf.placeholder('float',[None, self.noiseDim])
		###################################### For generation
		syn_latent = self.gan_obj.generator(z_noise)
		syn_image = self.cornn_obj.cornnDec(syn_latent)

		if not os.path.exists('result'):
			os.makedirs('result')

		saver = tf.train.Saver()
		random.seed(1234)
		with tf.Session() as sess:
			saver.restore(sess, model_file)

			for _ in range(1000):
				# Burning Generator
				randomX = np.random.normal(size=(batch_size, self.noiseDim))
				sess.run(syn_image, feed_dict={z_noise:randomX})
			# Generate Data
			randomX = np.random.normal(size=(noSamples, self.noiseDim))
			generated = sess.run(syn_image, feed_dict={z_noise:randomX})
			np.save('result/generatedData.npy', generated)

	# def corInLatentRepresentation(self, data_matrix, model_file):
	# 	x_data = np.copy(data_matrix)
	# 	x_left_raw = tf.placeholder(tf.float32, [None, self.left_view_dim])
	# 	x_right_raw = tf.placeholder(tf.float32, [None, self.right_view_dim])

	# 	_, _, encoded = self.cornn_obj.cornnEnc(x_left_raw, x_right_raw)

	# 	saver = tf.train.Saver()
	# 	with tf.Session() as sess:
	# 		saver.restore(sess, model_file)
	# 		common_rep = sess.run(encoded, feed_dict={x_left_raw:x_data[:,:self.left_view_dim], x_right_raw:x_data[:,self.right_view_dim:]})
	# 		print common_rep.sum()

def parse_arguments(parser):
	parser.add_argument('action', type=str, metavar='<action>', choices=['train', 'generate'], help='Train or Generate data')
	parser.add_argument('data_type', type=str, metavar='<data_type>', choices=['binary', 'count'], help='Data Type of input data...Binary/Count')
	parser.add_argument('data_file', type=str, metavar='<data_matrix>', help='Data Matrix')
	parser.add_argument('model_file', type=str, metavar='<model_filename>', default='model', help='The path to the model file, in case you want to continue training. (default value: '')')
	parser.add_argument('--noise_dim', type=int, default=32, help='Noise dim which is input of generator')
	parser.add_argument('--latent_space_dim', type=int, default=100, help='Latent space dimention...output of encoder or generator')
	parser.add_argument('--discriminator_update', type=int, default=2, help='The number of times to update the discriminator per epoch. (default value: 2)')
	parser.add_argument('--generator_update', type=int, default=1, help='The number of times to update the generator per epoch. (default value: 1)')
	parser.add_argument('--batch_size', type=int, default=240, help='batch-size')
	parser.add_argument('--pre_training_epoch', type=int, default=300, help='Pre-training epoch of cornn')
	parser.add_argument('--noEpochs', type=int, default=1000, help='No of epochs to train the model')
	parser.add_argument('--noSamples', type=int, default=1000, help='No of samples, you want to generate')
	args = parser.parse_args()
	return args		

if __name__=='__main__':
	parser = argparse.ArgumentParser()
	args = parse_arguments(parser)
	data = np.load(args.data_file)
	inputDim = data.shape[1]

	x_left, x_right = spliter(data, 0.5)

	model = Latent_Model(datatype=args.data_type,
						noiseDim=args.noise_dim,
						left_view_dim=x_left.shape[1],
						right_view_dim=x_right.shape[1],
						latent_space_dim=args.latent_space_dim)

	if args.action=="train":
		model.train(x_left = x_left,
					x_right = x_right, 
					model_file=args.model_file, 
					pre_training_epoch=args.pre_training_epoch,
					noEpochs=args.noEpochs,
					discriminator_update=args.discriminator_update,
					generator_update=args.generator_update,
					batch_size=args.batch_size)
	else:
		model.generateData(model_file=args.model_file)
		#model.corInLatentRepresentation(data_matrix=data, model_file=args.model_file)