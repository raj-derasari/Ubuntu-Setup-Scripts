import numpy as np


features = np.load('mnist_features.npy')


for i in range(len(features)):
	for j in range(len(features[0])):
		if features[i][j]!=0:
			features[i][j]=1


np.save('binary_mnist_features.npy',features)