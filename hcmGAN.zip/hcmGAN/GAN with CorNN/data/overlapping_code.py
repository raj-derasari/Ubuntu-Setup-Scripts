import numpy as np
import collections

x = np.load("skill_features.npy")
y = np.load("skill_labels.npy")
skills = np.load('skill_dict.npy')

dic = {}
profiles = {}

for i in range(y.shape[0]):
    idx = list(y[i]).index(max(list(y[i])))
    if idx not in dic.keys():
        dic[idx] = []
        profiles[idx] = 0

    profiles[idx] += 1
    for j in range(len(skills)):
        if x[i][j]>=0.7:
            dic[idx].append(j)

    print i

updated_dic = {}

for key in dic.keys():
    # diff_skills = len(set(dic[key]))
    counter = collections.Counter(dic[key])
    no_of_profiles = profiles[key]

    if key not in updated_dic.keys():
        updated_dic[key] = []

    MEAN = np.mean(counter.values())

    print MEAN, '\n\n'

    for counter_key in counter.keys():
        if counter[counter_key] > MEAN:
            updated_dic[key].append(counter_key)


common_skills_index_set = set(updated_dic[0]).intersection(set(updated_dic[1]),set(updated_dic[2]),set(updated_dic[3]),set(updated_dic[4]),set(updated_dic[5]))

common_skills_index_list = list(common_skills_index_set)

for index in common_skills_index_list:
    print skills[index]

    # print "\n\n"
    # VALUES = counter.values()
    # print "min: ", min(VALUES)/float(no_of_profiles)
    # print "max: ", max(VALUES)/float(no_of_profiles)
    # print "mean: ", np.mean(VALUES)/float(no_of_profiles)
    # print "var: ", np.var(VALUES)/float(no_of_profiles)
    # mean2 = (np.mean(VALUES)/float(no_of_profiles) + max(VALUES)/float(no_of_profiles))/2
    # thresh = (mean2 + max(VALUES)/float(no_of_profiles))/2
    # print "thresh: ", thresh 