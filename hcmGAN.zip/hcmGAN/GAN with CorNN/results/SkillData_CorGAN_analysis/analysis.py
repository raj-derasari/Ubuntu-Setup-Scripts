import numpy as np
import matplotlib.pyplot as plt

corloss = np.load('corLoss.npy')
plt.plot(corloss)
plt.xlabel('Epoch')
plt.ylabel('Correlation Loss')
plt.show()

decloss = np.load('decLoss.npy')
plt.plot(decloss)
plt.xlabel('Epoch')
plt.ylabel('Descriminator Loss')
plt.show()

genloss = np.load('genLoss.npy')
plt.plot(genloss)
plt.xlabel('Epoch')
plt.ylabel('Generator Loss')
plt.show()


