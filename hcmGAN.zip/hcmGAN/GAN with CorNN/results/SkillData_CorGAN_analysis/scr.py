import numpy as np

Y1=np.load("500_generated.npy")
Y2=np.load("1200_generated.npy")
print(Y1.shape)
print(Y2.shape)
