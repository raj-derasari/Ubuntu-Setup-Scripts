from __future__ import division
import numpy as np
import matplotlib.pyplot as plt

def binarized(matrix, threshold):
    row = matrix.shape[0]
    column = matrix.shape[1]

    for i in range(row):
        for j in range(column):
            if matrix[i][j]>=threshold:
                matrix[i][j]=1
            else:
                matrix[i][j]=0

original = np.load(open('matrix.npy','rb'))
generated = np.load(open('1000_generated.npy','rb'))

binarized(original, 0.4)
binarized(generated, 0.4)

sum_original = list(np.sum(original, axis=0))
sum_generated = list(np.sum(generated, axis=0))

row_original = original.shape[0]
row_generated = generated.shape[0]

print row_generated
print row_original

sum_generated = [value * (1.0/row_generated) for value in sum_generated]
sum_original = [value * (1.0/row_original) for value in sum_original]

plt.scatter(sum_original, sum_generated)
plt.xlim([0,1])
plt.ylim([0,1])
plt.show()