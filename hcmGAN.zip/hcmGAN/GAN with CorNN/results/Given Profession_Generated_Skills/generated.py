import numpy as np

generated = np.load('1400_generated.npy')

skills = np.load('skill_dict.npy')
prof = ['application developer','web designer','net developer','java developer','application support analyst','applications engineer']
file_d = open('latest_correlation.txt','w')

for i in range(1000):
    # max_ind = list(_input[i]).index(max(list(_input[i])))
    # file_d.write('profession :- '+prof[max_ind]+'\n')
    gen_str = ''
    for j in range(len(skills)):
        if generated[i][j]>=0.7:
            gen_str += str(skills[j])+', '
    file_d.write('generate data :- '+gen_str+'\n\n')
file_d.close()
