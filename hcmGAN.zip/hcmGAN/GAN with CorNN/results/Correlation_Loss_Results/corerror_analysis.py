import matplotlib.pyplot as plt

epoch_mnist = [100,200,300,400,500,600,700,800,900]
epoch_skill = [0,100,200,300,400,500,600,700,800,900,1000,1100,1200,1300,1400]

with open("error_Corgan_mnist.txt","r") as f:
    content = f.readlines()
# you may also want to remove whitespace characters like `\n` at the end of each line
error_Corgan_mnist = [round(float(x.strip()),2) for x in content]
print error_Corgan_mnist

with open("error_Medgan_mnist.txt","r") as f:
    content = f.readlines()
# you may also want to remove whitespace characters like `\n` at the end of each line
error_Medgan_mnist = [round(float(x.strip()),2) for x in content]
print error_Medgan_mnist

with open("error_skill_corgan.txt","r") as f:
    content = f.readlines()
# you may also want to remove whitespace characters like `\n` at the end of each line
error_skill_corgan = [1-float(round(float(x.strip()),2)) for x in content]
print error_skill_corgan

with open("error_skill_medgan.txt","r") as f:
    content = f.readlines()
# you may also want to remove whitespace characters like `\n` at the end of each line
error_skill_medgan = [1-float(round(float(x.strip()),2)) for x in content]
print error_skill_medgan

plt.plot(epoch_mnist, error_Corgan_mnist)
plt.plot(epoch_mnist, error_Medgan_mnist)
plt.legend(['corrGAN', 'medGAN'], loc='right')
plt.title('Correlation Loss - MNIST generated data')
plt.xlabel('Epoch')
plt.ylabel('Correlation Loss')
plt.ylim([0,1])
plt.savefig('MNIST_Correlation_Loss_On_Generated.png')
plt.show()

plt.plot(epoch_skill, error_skill_corgan, linestyle='--', marker='o', color='g')
plt.plot(epoch_skill, error_skill_medgan, linestyle='--', marker='*', color='b')
plt.legend(['corrGAN', 'medGAN'], loc='center right')
plt.title('Correlation on Generated skill-data')
plt.xlabel('Epochs')
plt.ylabel('Correlation')
plt.ylim([0,1])
plt.savefig('SKILL_Correlation_On_Generated.png')
plt.show()
