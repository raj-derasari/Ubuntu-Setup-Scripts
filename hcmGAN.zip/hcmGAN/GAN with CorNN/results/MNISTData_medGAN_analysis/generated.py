import numpy as np
import matplotlib.pyplot as plt

for epoch in range(0,1401,100):
	generated = np.load(str(epoch)+'_generated.npy')

	# plt.subplot(2, 2, 1)
	plt.imshow(np.reshape(generated[0],(28,28)), cmap='gray')
	plt.savefig('mnist result medGAN/epoch_'+str(epoch)+'_1.png', bbox_inches='tight')
	# plt.subplot(2, 2, 2)
	plt.imshow(np.reshape(generated[1],(28,28)),cmap='gray')
	plt.savefig('mnist result medGAN/epoch_'+str(epoch)+'_2.png', bbox_inches='tight')
	# plt.subplot(2, 2, 3)
	plt.imshow(np.reshape(generated[2],(28,28)), cmap='gray')
	plt.savefig('mnist result medGAN/epoch_'+str(epoch)+'_3.png', bbox_inches='tight')
	# plt.subplot(2, 2, 4)
	# plt.imshow(np.reshape(generated[3],(28,28)),cmap='gray')
	# plt.suptitle('Generated Images using medGAN - Epoch:'+str(epoch))
	# plt.savefig('mnist result medGAN/epoch_'+str(epoch)+'.png', bbox_inches='tight')
