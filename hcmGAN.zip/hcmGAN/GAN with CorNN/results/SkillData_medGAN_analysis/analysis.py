import numpy as np
import matplotlib.pyplot as plt

recLoss = np.load('recLoss.npy')
plt.plot(recLoss)
plt.show()

recLoss = np.load('decLoss.npy')
plt.plot(recLoss)
plt.show()

recLoss = np.load('genLoss.npy')
plt.plot(recLoss)
plt.show()
