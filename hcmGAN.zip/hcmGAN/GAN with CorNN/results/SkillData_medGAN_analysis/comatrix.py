from __future__ import division
import numpy as np

def thresold(a):
    r=a.shape[0]
    c=a.shape[1]
    for i in range(r):
        for j in range(c):
            if a[i][j]>=0.7:
                a[i][j]=1
            else:
                a[i][j]=0
    return a

# Return list of 1's index
def oneindex(a):
    l=[]
    for i in range(len(a)):
        if a[i]==1:
            l.append(i)
    return l

# Return Matrix of co-accurences.
def comatrix(a,cr,cnt):
    for i in range(len(a)):
        for j in range(i+1,len(a)):
            #print cr[i][j]
            cr[a[i]][a[j]]+=1
            cr[a[j]][a[i]]+=1
        cnt+=1
    return cr,cnt

def check_symmetric(a, tol=1e-8):
	a=np.array(a)
	return np.allclose(a, a.T, atol=tol)


def norm(a,cnt):
	for i in range(len(a)):
		for j in range(len(a)):
			a[i][j]=a[i][j]/cnt
	return a

######## MAIN FUNCTION ###########


g_data=np.load('matrix.npy')
t=7055
cr=[[0 for i in range(t)]for j in range(t)]

gmatrix=g_data

#print "Rmatrix: ",len(rmatrix),len(rmatrix[0])
#print "Gmatrix: ",len(gmatrix),len(gmatrix[0])

# Converting into Binary matrix.
gmatrix=thresold(gmatrix)
print "QQQQQ"
ocnt=0
for i in gmatrix:
    l=oneindex(i)
    #cr=comatrix(l,cr)
    cr,ocnt=comatrix(l,cr,ocnt)
print ocnt
xx=0
norm_cr=norm(cr,ocnt)
np.save('./Norm/matrix.npy',norm_cr)
for i in norm_cr:
	for j in i:
		if j>=1:
			xx+=1
print xx
