from __future__ import division
import tensorflow as tf
import os, random
import numpy as np
from tensorflow.contrib.layers import l2_regularizer, xavier_initializer, batch_norm
import matplotlib.pyplot as plt

# split data in given ration column wise
def spliter(mat, ratio):
    dim = mat.shape[1]
    left = int(dim*ratio)
    left_mat = mat[:, :left]
    right_mat = mat[:, left:]
    return left_mat, right_mat

class CorGAN(object):
    def __init__(self,
                x_datafile='',
                y_datafile='',
                squeezeDim=128,
                randomDim=128,
                generatorDims=(128,128),
                discriminatorDims=(256,64,1),
                l2_scale=0.001,
                split_ratio=0.8,
                bnDecay=0.99):

        self.l2_scale = l2_scale
        self.squeezeDim = squeezeDim
        self.randomDim = randomDim
        self.generatorDims = list(generatorDims) + [squeezeDim]
        self.encodeActivation = tf.nn.tanh
        self.decodeActivation = tf.nn.sigmoid
        self.generatorActivation = tf.nn.relu
        self.discriminatorActivation = tf.nn.relu
        self.bnDecay = bnDecay
        self.discriminatorDims = list(discriminatorDims)

        feature = np.load(x_datafile) # load x_view data
        label = np.load(y_datafile) # load y_view data

        # shuffle data matrices
        shuffle_index = np.arange(feature.shape[0])
        np.random.shuffle(shuffle_index)
        left_mat = feature[shuffle_index]
        right_mat = label[shuffle_index]

        # create training and testing dataset
        dim = int(left_mat.shape[0]*split_ratio)

        # generate feature vectors only
        self.x_view_train, self.y_view_train = spliter(left_mat[:dim,:],0.5)
        self.x_view_test, self.y_view_test = spliter(left_mat[dim:,:],0.5)

        # generate data based on profession vector as well
        # self.x_view_train = left_mat[:dim]
        # self.y_view_train = right_mat[:dim]
        # self.x_view_test = left_mat[dim:]
        # self.y_view_test = right_mat[dim:]

        # take dimensions for x-view and y-view
        self.left_dim = self.x_view_train.shape[1]
        self.right_dim = self.y_view_train.shape[1]

    # Correlation neural network model
    def CorNN(self, leftX, rightY, reuse=False):
        decoderVariables = {}
        with tf.variable_scope('corNN', reuse=reuse, regularizer=l2_regularizer(self.l2_scale)):
            X, Y = leftX, rightY
            W = tf.get_variable('corNN_W', shape=[self.left_dim, self.squeezeDim])  # W of (x_view_dim * squeezeDim)
            V = tf.get_variable('corNN_V', shape=[self.right_dim, self.squeezeDim]) # W of (y_view_dim * squeezeDim)
            b = tf.get_variable('corNN_b', shape=[self.squeezeDim]) # bias of squeezeDim
            h_x = tf.matmul(X, W) # latent represention of x_view with dimensions (batchsize * squeezeDim)
            h_y = tf.matmul(Y, V) # latent represention of y_view with dimensions (batchsize * squeezeDim)
            h_z = self.encodeActivation(h_x + h_y + b) # latent represention of x_view and y_view

            latent_z = h_z
            W_hat = tf.get_variable('corNN_W_hat', shape=[self.squeezeDim, self.left_dim]) # W' of (squeezeDim * x_view_dim)
            V_hat = tf.get_variable('corNN_V_hat', shape=[self.squeezeDim, self.right_dim]) # V' of (squeezeDim * x_view_dim)
            b_hat = tf.get_variable('corNN_b_hat', shape=[self.left_dim + self.right_dim])        # dim = d1 + d2
            decoderVariables['corNN_W_hat'] = W_hat
            decoderVariables['corNN_V_hat'] = V_hat
            decoderVariables['corNN_b_hat'] = b_hat

            h_xhat = tf.matmul(latent_z, W_hat) # x_view reconstruction with dimensions (batchsize * x_view_dim)
            h_yhat = tf.matmul(latent_z, V_hat) # y_view reconstruction with dimensions (batchsize * y_view_dim)
            h_con = tf.concat([h_xhat, h_yhat], 1) # concate to views
            z_hat = self.decodeActivation(tf.add(h_con, b_hat)) # dim = batchsize * (d1+d2)
            return z_hat, h_x, h_y, h_z, decoderVariables

    def Generator(self, z, y_input, bn_train, reuse=False):
        tempVec = z
        tempDim = self.randomDim
        # tempVec = tf.concat([z, y_input],1)
        # tempDim = self.randomDim + self.right_dim
        with tf.variable_scope('generator', reuse=reuse, regularizer=l2_regularizer(self.l2_scale)):
            i=0
            for _, genDim in enumerate(self.generatorDims[:-1]):
                W = tf.get_variable('gen_W'+str(i), shape=[tempDim, genDim])
                h = tf.matmul(tempVec,W)
                h2 = batch_norm(h, decay=self.bnDecay, scale=True, is_training=bn_train, updates_collections=None)
                h3 = self.generatorActivation(h2)
                tempVec = h3 + tempVec
                tempDim, i = genDim, i+1
            W = tf.get_variable('gen_W'+str(i), shape=[tempDim, self.generatorDims[-1]])
            h = tf.matmul(tempVec,W)
            h2 = batch_norm(h, decay=self.bnDecay, scale=True, is_training=bn_train, updates_collections=None)
            h3 = tf.nn.tanh(h2) + tempVec
        return h3

    def Discriminator(self, x_input, keepRate, reuse=False):
        batchSize = tf.shape(x_input)[0]
        inputMean = tf.reshape(tf.tile(tf.reduce_mean(x_input,0), [batchSize]), (batchSize, self.left_dim + self.right_dim))
        tempVec = tf.concat([x_input, inputMean], 1)
        # tempVec = x_input
        tempDim = (self.left_dim + self.right_dim) * 2
        with tf.variable_scope('discriminator', reuse=reuse, regularizer=l2_regularizer(self.l2_scale)):
            i = 0
            for _, discDim in enumerate(self.discriminatorDims[:-1]):
                W = tf.get_variable('dec_W'+str(i), shape=[tempDim, discDim])
                b = tf.get_variable('dec_b'+str(i), shape=[discDim])
                h = self.discriminatorActivation(tf.add(tf.matmul(tempVec,W),b))
                h = tf.nn.dropout(h, keepRate)
                tempVec = h
                tempDim = discDim
                i+=1
            W = tf.get_variable('dec_W'+str(i), shape=[tempDim, 1])
            b = tf.get_variable('dec_b'+str(i), shape=[1])
            y_hat = tf.squeeze(tf.nn.sigmoid(tf.add(tf.matmul(tempVec, W), b)))
        return y_hat

    def train(self,
              batchsize=120,
              corNNEpochs=300,
              noEpochs=3000,
              generatorEpoch=1,
              discriminatorEpoch=2,
              saveMaxKeep=0):
        # create placeholder
        left_input = tf.placeholder('float', [None, self.left_dim])
        right_input = tf.placeholder('float', [None, self.right_dim])
        left_zeros = tf.placeholder('float', [None, self.left_dim])
        right_zeros = tf.placeholder('float', [None, self.right_dim])
        x_random = tf.placeholder('float',[None, self.randomDim])
        keep_prob = tf.placeholder('float')
        bn_train = tf.placeholder('bool')

        # input data [x, y] views
        input_data = tf.concat([left_input, right_input],1)
        # Correlation Neural Network function for reconstruction of data
        recon_z, h_X, h_Y, h_Z, decoderVariables  = self.CorNN(left_input, right_input)
        # Correlation Neural Network function for reconstruction of right_input given left_input
        cross_x, _, _, _, _ = self.CorNN(left_input, right_zeros, reuse=True)
        # Correlation Neural Network function for reconstruction of left_input given right_input
        cross_y, _, _, _, _ = self.CorNN(left_zeros, right_input, reuse=True)
        # Generate latent space
        x_latent = self.Generator(x_random, right_input, bn_train)
        # try to construction data from generated latent space
        h_xhat = tf.matmul(x_latent, decoderVariables['corNN_W_hat']) # x_view reconstruction with dimensions (batchsize * x_view_dim)
        h_yhat = tf.matmul(x_latent, decoderVariables['corNN_V_hat']) # y_view reconstruction with dimensions (batchsize * y_view_dim)
        h_con = tf.concat([h_xhat, h_yhat], 1) # concate to views
        z_hat = self.decodeActivation(tf.add(h_con, decoderVariables['corNN_b_hat'])) # dim = batchsize * (d1+d2)
        y_hat_real = self.Discriminator(input_data, keep_prob)
        y_hat_fake = self.Discriminator(z_hat, keep_prob, reuse=True)

        # loss functions
        recon_loss = tf.reduce_mean(-tf.reduce_sum(input_data * tf.log(recon_z + 1e-12) + (1. - input_data) * tf.log(1. - recon_z + 1e-12), 1), 0)
        crossx_yloss = tf.reduce_mean(-tf.reduce_sum(input_data * tf.log(cross_x + 1e-12) + (1. - input_data) * tf.log(1. - cross_x + 1e-12), 1), 0)
        crossy_xloss = tf.reduce_mean(-tf.reduce_sum(input_data * tf.log(cross_y + 1e-12) + (1. - input_data) * tf.log(1. - cross_y + 1e-12), 1), 0)
        # recon_loss = tf.reduce_mean((input_data - recon_z)**2)
        # crossx_yloss = tf.reduce_mean((input_data - cross_x)**2)
        # crossy_xloss = tf.reduce_mean((input_data - cross_y)**2)

        hx_centered = h_X - tf.reduce_mean(h_X, axis=0)
        hy_centered = h_Y - tf.reduce_mean(h_Y, axis=0)
        corr_nr = tf.reduce_sum(hx_centered * hy_centered, axis=0)
        corr_dr1 = tf.sqrt(tf.reduce_sum(hx_centered * hx_centered, axis=0))
        corr_dr2 = tf.sqrt(tf.reduce_sum(hy_centered * hy_centered, axis=0))
        corr_dr = corr_dr1 * corr_dr2
        corr = corr_nr/corr_dr
        latent_loss = tf.reduce_sum(corr)

        # final loss functions
        total_loss = recon_loss + crossx_yloss + crossy_xloss - latent_loss
        loss_d = -tf.reduce_mean(tf.log(y_hat_real + 1e-12)) - tf.reduce_mean(tf.log(1. - y_hat_fake + 1e-12))
        loss_g = -tf.reduce_mean(tf.log(y_hat_fake + 1e-12))

        # pool out trainable variables for optimization
        t_vars = tf.trainable_variables()
        cornn_vars = [var for var in t_vars if 'corNN' in var.name]
        d_vars = [var for var in t_vars if 'discriminator' in var.name]
        g_vars = [var for var in t_vars if 'generator' in var.name]
        all_regs = tf.get_collection(tf.GraphKeys.REGULARIZATION_LOSSES)

        # Optimization functions
        optimize_cornn = tf.train.AdamOptimizer().minimize(total_loss+sum(all_regs), var_list=cornn_vars)
        optimize_d = tf.train.AdamOptimizer().minimize(loss_d + sum(all_regs), var_list=d_vars)
        optimize_g = tf.train.AdamOptimizer().minimize(loss_g + sum(all_regs), var_list=g_vars+decoderVariables.values())

        initOp = tf.global_variables_initializer()

        if not os.path.exists('result'):
            os.makedirs('result')
        if not os.path.exists('model'):
            os.makedirs('model')

        saver = tf.train.Saver(max_to_keep=saveMaxKeep)
        noBatches = int(self.x_view_train.shape[0]/batchsize)
        idx = np.arange(self.x_view_train.shape[0])
        with tf.Session() as sess:
            sess.run(initOp)
            cor_loss = []
            reconstruction_loss = []
            for corepoch in range(corNNEpochs):
                avgcor_loss = []
                rec_loss = []
                for _ in range(noBatches):
                    batchIdx = np.random.choice(idx, size=batchsize, replace=False)
                    l_input, r_input = self.x_view_train[batchIdx], self.y_view_train[batchIdx]
                    l_zeros = np.zeros([batchsize, self.left_dim])
                    r_zeros = np.zeros([batchsize, self.right_dim])
                    _, loss, rloss = sess.run([optimize_cornn, total_loss, recon_loss], \
                                                            feed_dict={left_input:l_input, right_input:r_input, left_zeros: l_zeros, right_zeros: r_zeros})
                    avgcor_loss.append(loss)
                    rec_loss.append(rloss)
                acl = np.mean(avgcor_loss)
                cor_loss.append(acl)
                reconstruction_loss.append(np.mean(rec_loss))
                print  'Pre-Epoch:- ',corepoch, 'Correlation Loss:- ', acl
            np.save('result/corLoss.npy', cor_loss)
            np.save('result/recLoss.npy', reconstruction_loss)

            genLoss, decLoss = [], []
            for epoch in range(noEpochs):
                avggenLoss, avgdecLoss = [], []
                for _ in range(noBatches):
                    random.seed(1234)
                    for _ in range(discriminatorEpoch):
                        batchIdx = np.random.choice(idx, size=batchsize, replace=False)
                        l_input, r_input = self.x_view_train[batchIdx], self.y_view_train[batchIdx]
                        randomX = np.random.normal(size=(batchsize, self.randomDim))
                        _, dloss = sess.run([optimize_d, loss_d], feed_dict={left_input:l_input, right_input:r_input, x_random:randomX, bn_train:False, keep_prob:1.0})
                        avgdecLoss.append(dloss)

                    for _ in range(generatorEpoch):
                        batchIdx = np.random.choice(idx, size=batchsize, replace=False)
                        r_input = self.y_view_train[batchIdx]
                        randomX = np.random.normal(size=(batchsize, self.randomDim))
                        _, gloss = sess.run([optimize_g, loss_g], feed_dict={x_random:randomX, right_input:r_input, bn_train:True, keep_prob:1.0})
                        avggenLoss.append(gloss)
                adl, agl = np.mean(avgdecLoss), np.mean(avggenLoss)
                decLoss.append(adl)
                genLoss.append(agl)
                print 'Epoch :- ',epoch,'Discriminator loss: - ', adl, 'Generator Loss :- ', agl
                savePath = saver.save(sess, 'model/mod', global_step=epoch)

                if epoch%100==0:
                    random.seed(9001)
                    _input = self.y_view_test[:1000,:]
                    randomX = np.random.normal(size=(1000, self.randomDim))
                    generated = sess.run(z_hat, feed_dict={x_random:randomX, right_input:_input, bn_train:False})
                    np.save('result/'+str(epoch)+'_generated.npy',generated)

                    plt.subplot(2, 2, 1)
                    plt.imshow(np.reshape(generated[0],(28,28)), cmap='gray')
                    plt.title('Generated 1')
                    plt.subplot(2, 2, 2)
                    plt.imshow(np.reshape(generated[1],(28,28)),cmap='gray')
                    plt.title('Generated 2')
                    plt.subplot(2, 2, 3)
                    plt.imshow(np.reshape(generated[2],(28,28)), cmap='gray')
                    plt.title('Generated 3')
                    plt.subplot(2, 2, 4)
                    plt.imshow(np.reshape(generated[3],(28,28)),cmap='gray')
                    plt.title('Generated 4')
                    plt.savefig('result/epoch_'+str(epoch)+'.png')
            np.save('result/genLoss.npy', genLoss)
            np.save('result/decLoss.npy', decLoss)
                    # _input = np.zeros([1000,6])
                    # for l in range(1000):
                    #     _input[l][0] = 1
                    # randomX = np.random.normal(size=(1000, self.randomDim))
                    # generated = sess.run(z_hat, feed_dict={x_random:randomX, right_input:_input, bn_train:False})
                    # np.save('result/'+str(epoch)+'_generated.npy',generated[:,:self.left_dim])

if __name__=="__main__":
    cor_gan_obj = CorGAN('data/binary_mnist_features.npy','data/mnist_labels.npy')
    cor_gan_obj.train()
