import numpy as np
import matplotlib.pyplot as plt

corloss = np.load('result/corLoss.npy')
plt.plot(corloss)
plt.xlabel('Epoch')
plt.ylabel('Correlation Loss')
plt.show()

decloss = np.load('result/decLoss.npy')
plt.plot(decloss)
plt.xlabel('Epoch')
plt.ylabel('Descriminator Loss')
plt.show()

genloss = np.load('result/genLoss.npy')
plt.plot(genloss)
plt.xlabel('Epoch')
plt.ylabel('Generator Loss')
plt.show()
