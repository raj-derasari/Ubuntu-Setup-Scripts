import numpy as np

'''
For given matrix,
this function will find co-relation matrix
(symmetric matrix)
'''
def buildcorrelation(x_input, threshold):
	dim = x_input.shape[1]
	coh_X = np.zeros([dim,dim])
	for i in range(dim-1):
		for j in range(i+1, dim):
			counter = 0
			for k in range(dim):
				if x_input[k][i]>threshold and x_input[k][j]>threshold:
					counter+=1;
			coh_X[i][j]=counter
			coh_X[j][i]=counter
	return coh_X/dim # change in Normalization of you find it is required
########################################################


a = [[1,0,0],\
	[0,1,1],
	[1,1,1]]

print buildcorrelation(np.array(a), 0.7)