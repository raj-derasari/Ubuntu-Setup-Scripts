import cPickle

f1=open("index2word.pickle","rb")
conv=cPickle.load(f1)
f1.close()

f2= open("save/eval_file.txt","rb")
numbers=f2.read().split()
f2.close()


for n in numbers:
	print n,' :- ', conv[int(n)],'\n'
