import numpy as np

with open("save/real_data.txt", 'r') as f:
    token_stream = []
    batch_size=64
    for line in f:  
		line = line.strip()                     #removes all whitespaces at the start and end.
		line = line.split()                     #List of token
		parse_line = [int(x) for x in line] 
		if len(parse_line) == 20:               #Sequence length of 20 maintained
                    token_stream.append(parse_line)
    num_batch = int(len(token_stream) / batch_size)             #Total number of batches formed /64
    token_stream = token_stream[:num_batch * batch_size]        #This is to maintain the fact that all batches contain exactly 20 words    
    sequence_batch = np.split(np.array(token_stream), num_batch, 0)
    print len(sequence_batch[0][0])